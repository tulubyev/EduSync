/**
 * Deadlines Screen Component
 * Displays all deadlines across courses
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../components/ThemeProvider';
import { apiService } from '../shared/services/api.service';

// Types
interface Deadline {
  id: number;
  title: string;
  description: string | null;
  courseId: number;
  courseName: string;
  dueDate: string;
  completed: boolean;
}

const DeadlinesScreen: React.FC = () => {
  const navigation = useNavigation();
  const { colors } = useTheme();
  const [deadlines, setDeadlines] = useState<Deadline[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [filter, setFilter] = useState<'all' | 'upcoming' | 'completed'>('upcoming');

  useEffect(() => {
    loadDeadlines();
  }, [filter]);

  const loadDeadlines = async () => {
    setIsLoading(true);
    try {
      let endpoint = '/api/deadlines';
      
      if (filter === 'upcoming') {
        endpoint = '/api/deadlines/upcoming';
      }
      
      const response = await apiService.get<Deadline[]>(endpoint);
      
      // Filter completed items if needed
      let filteredDeadlines = response || [];
      if (filter === 'completed') {
        filteredDeadlines = filteredDeadlines.filter(item => item.completed);
      }
      
      // Sort by due date
      filteredDeadlines.sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());
      
      setDeadlines(filteredDeadlines);
    } catch (error) {
      console.error('Error loading deadlines:', error);
      setDeadlines([]);
    } finally {
      setIsLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDeadlines();
    setRefreshing(false);
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Calculate days remaining
  const getDaysRemaining = (dateString: string) => {
    const dueDate = new Date(dateString);
    const today = new Date();
    
    // Reset time to midnight for accurate day calculation
    dueDate.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);
    
    const diffTime = dueDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    return diffDays;
  };

  // Mark deadline as complete
  const toggleDeadlineCompletion = async (id: number, completed: boolean) => {
    try {
      await apiService.patch(`/api/deadlines/${id}/complete`, {
        completed: !completed,
      });
      
      // Update local state
      setDeadlines(prevDeadlines =>
        prevDeadlines.map(deadline =>
          deadline.id === id
            ? { ...deadline, completed: !completed }
            : deadline
        )
      );
    } catch (error) {
      console.error('Error updating deadline:', error);
    }
  };

  // Navigate to course detail
  const navigateToCourse = (courseId: number) => {
    navigation.navigate('CourseDetail' as never, { courseId } as never);
  };

  const renderDeadlineItem = ({ item }: { item: Deadline }) => {
    const daysRemaining = getDaysRemaining(item.dueDate);
    const isPastDue = daysRemaining < 0;
    const isDueToday = daysRemaining === 0;
    
    return (
      <View style={styles.deadlineItem}>
        <TouchableOpacity
          style={[
            styles.deadlineCheckbox,
            item.completed && { backgroundColor: colors.primary, borderColor: colors.primary },
          ]}
          onPress={() => toggleDeadlineCompletion(item.id, item.completed)}
        >
          {item.completed && <Text style={styles.checkmark}>✓</Text>}
        </TouchableOpacity>
        
        <View style={styles.deadlineContent}>
          <Text
            style={[
              styles.deadlineTitle,
              item.completed && styles.completedText,
            ]}
            numberOfLines={1}
          >
            {item.title}
          </Text>
          
          <TouchableOpacity onPress={() => navigateToCourse(item.courseId)}>
            <Text style={styles.deadlineCourse}>{item.courseName}</Text>
          </TouchableOpacity>
          
          {item.description && (
            <Text
              style={[
                styles.deadlineDescription,
                item.completed && styles.completedText,
              ]}
              numberOfLines={1}
            >
              {item.description}
            </Text>
          )}
        </View>
        
        <View style={styles.deadlineDateContainer}>
          <Text style={styles.deadlineDate}>{formatDate(item.dueDate)}</Text>
          
          {!item.completed && (
            <Text
              style={[
                styles.deadlineStatus,
                isPastDue && styles.deadlineOverdue,
                isDueToday && styles.deadlineToday,
              ]}
            >
              {isPastDue
                ? `${Math.abs(daysRemaining)} days overdue`
                : isDueToday
                  ? 'Due today'
                  : `${daysRemaining} days left`}
            </Text>
          )}
        </View>
      </View>
    );
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      padding: 16,
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: colors.text,
      marginBottom: 16,
    },
    filtersContainer: {
      flexDirection: 'row',
      paddingBottom: 8,
    },
    filterButton: {
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 16,
      marginRight: 8,
      borderWidth: 1,
      borderColor: colors.border,
    },
    filterButtonActive: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    filterText: {
      fontSize: 14,
      color: colors.textSecondary,
    },
    filterTextActive: {
      color: 'white',
      fontWeight: '500',
    },
    content: {
      flex: 1,
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    deadlineItem: {
      flexDirection: 'row',
      alignItems: 'center',
      padding: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    deadlineCheckbox: {
      width: 24,
      height: 24,
      borderRadius: 4,
      borderWidth: 2,
      borderColor: colors.border,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
    },
    checkmark: {
      color: 'white',
      fontSize: 14,
      fontWeight: 'bold',
    },
    deadlineContent: {
      flex: 1,
      marginRight: 12,
    },
    deadlineTitle: {
      fontSize: 16,
      fontWeight: '500',
      color: colors.text,
      marginBottom: 4,
    },
    deadlineCourse: {
      fontSize: 13,
      color: colors.primary,
      marginBottom: 2,
    },
    deadlineDescription: {
      fontSize: 13,
      color: colors.textSecondary,
    },
    deadlineDateContainer: {
      alignItems: 'flex-end',
    },
    deadlineDate: {
      fontSize: 13,
      color: colors.textSecondary,
      marginBottom: 4,
    },
    deadlineStatus: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    deadlineOverdue: {
      color: colors.error,
      fontWeight: '500',
    },
    deadlineToday: {
      color: colors.secondary,
      fontWeight: '500',
    },
    completedText: {
      textDecorationLine: 'line-through',
      color: colors.textSecondary,
    },
    emptyState: {
      padding: 40,
      alignItems: 'center',
      justifyContent: 'center',
    },
    emptyStateText: {
      fontSize: 16,
      color: colors.textSecondary,
      textAlign: 'center',
    },
    backButton: {
      paddingVertical: 8,
      paddingHorizontal: 16,
      marginBottom: 8,
    },
    backButtonText: {
      fontSize: 16,
      color: colors.primary,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        
        <Text style={styles.headerTitle}>Deadlines</Text>
        
        <View style={styles.filtersContainer}>
          <TouchableOpacity
            style={[
              styles.filterButton,
              filter === 'upcoming' && styles.filterButtonActive,
            ]}
            onPress={() => setFilter('upcoming')}
          >
            <Text
              style={[
                styles.filterText,
                filter === 'upcoming' && styles.filterTextActive,
              ]}
            >
              Upcoming
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.filterButton,
              filter === 'completed' && styles.filterButtonActive,
            ]}
            onPress={() => setFilter('completed')}
          >
            <Text
              style={[
                styles.filterText,
                filter === 'completed' && styles.filterTextActive,
              ]}
            >
              Completed
            </Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[
              styles.filterButton,
              filter === 'all' && styles.filterButtonActive,
            ]}
            onPress={() => setFilter('all')}
          >
            <Text
              style={[
                styles.filterText,
                filter === 'all' && styles.filterTextActive,
              ]}
            >
              All
            </Text>
          </TouchableOpacity>
        </View>
      </View>
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : deadlines.length > 0 ? (
        <FlatList
          data={deadlines}
          renderItem={renderDeadlineItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.content}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      ) : (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>
            {filter === 'upcoming'
              ? 'No upcoming deadlines. You\'re all caught up!'
              : filter === 'completed'
                ? 'No completed deadlines yet.'
                : 'No deadlines found. Add deadlines to your courses to see them here.'}
          </Text>
        </View>
      )}
    </View>
  );
};

export default DeadlinesScreen;