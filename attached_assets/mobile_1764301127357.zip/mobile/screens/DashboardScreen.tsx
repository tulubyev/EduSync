/**
 * Dashboard Screen Component
 * Main screen after login, showing user's courses and deadlines
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
  FlatList,
  ActivityIndicator,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../components/ThemeProvider';
import { authService } from '../shared/services/auth.service';
import { apiService } from '../shared/services/api.service';

// Types
interface Course {
  id: number;
  title: string;
  platform: string;
  progress: number;
  imageUrl?: string;
}

interface Deadline {
  id: number;
  title: string;
  courseId: number;
  courseName: string;
  dueDate: string;
  completed: boolean;
}

const DashboardScreen: React.FC = () => {
  const navigation = useNavigation();
  const { colors } = useTheme();
  const [refreshing, setRefreshing] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [courses, setCourses] = useState<Course[]>([]);
  const [deadlines, setDeadlines] = useState<Deadline[]>([]);
  const [loadingCourses, setLoadingCourses] = useState(true);
  const [loadingDeadlines, setLoadingDeadlines] = useState(true);

  // Load user data
  useEffect(() => {
    setUser(authService.getUser());
  }, []);

  // Load courses and deadlines
  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    await Promise.all([
      loadCourses(),
      loadDeadlines(),
    ]);
  };

  const loadCourses = async () => {
    setLoadingCourses(true);
    try {
      const response = await apiService.get<Course[]>('/api/courses');
      setCourses(response || []);
    } catch (error) {
      console.error('Error loading courses:', error);
      setCourses([]);
    } finally {
      setLoadingCourses(false);
    }
  };

  const loadDeadlines = async () => {
    setLoadingDeadlines(true);
    try {
      const response = await apiService.get<Deadline[]>('/api/deadlines/upcoming');
      setDeadlines(response || []);
    } catch (error) {
      console.error('Error loading deadlines:', error);
      setDeadlines([]);
    } finally {
      setLoadingDeadlines(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      await loadDashboardData();
    } finally {
      setRefreshing(false);
    }
  };

  // Handle course item press
  const handleCoursePress = (courseId: number) => {
    navigation.navigate('CourseDetail' as never, { courseId } as never);
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Mark deadline as complete
  const toggleDeadlineCompletion = async (deadlineId: number, currentStatus: boolean) => {
    try {
      await apiService.patch(`/api/deadlines/${deadlineId}/complete`, {
        completed: !currentStatus,
      });
      
      // Update local state
      setDeadlines(prevDeadlines =>
        prevDeadlines.map(deadline =>
          deadline.id === deadlineId
            ? { ...deadline, completed: !currentStatus }
            : deadline
        )
      );
    } catch (error) {
      console.error('Error updating deadline:', error);
    }
  };

  // Render course item
  const renderCourseItem = ({ item }: { item: Course }) => (
    <TouchableOpacity
      style={styles.courseCard}
      onPress={() => handleCoursePress(item.id)}
    >
      <View style={styles.courseHeader}>
        <Text style={styles.coursePlatform}>{item.platform}</Text>
      </View>
      <Text style={styles.courseTitle} numberOfLines={2}>
        {item.title}
      </Text>
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View
            style={[
              styles.progressFill,
              { width: `${item.progress}%`, backgroundColor: colors.primary },
            ]}
          />
        </View>
        <Text style={styles.progressText}>{item.progress}%</Text>
      </View>
    </TouchableOpacity>
  );

  // Render deadline item
  const renderDeadlineItem = ({ item }: { item: Deadline }) => (
    <View style={styles.deadlineItem}>
      <TouchableOpacity
        style={[
          styles.deadlineCheckbox,
          item.completed && { backgroundColor: colors.primary, borderColor: colors.primary },
        ]}
        onPress={() => toggleDeadlineCompletion(item.id, item.completed)}
      >
        {item.completed && <Text style={styles.checkmark}>✓</Text>}
      </TouchableOpacity>
      <View style={styles.deadlineContent}>
        <Text
          style={[
            styles.deadlineTitle,
            item.completed && styles.completedText,
          ]}
          numberOfLines={1}
        >
          {item.title}
        </Text>
        <Text style={styles.deadlineCourse}>{item.courseName}</Text>
      </View>
      <Text style={styles.deadlineDate}>
        {formatDate(item.dueDate)}
      </Text>
    </View>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      padding: 20,
      backgroundColor: colors.primary,
    },
    welcomeText: {
      fontSize: 14,
      color: 'rgba(255, 255, 255, 0.8)',
      marginBottom: 4,
    },
    userName: {
      fontSize: 20,
      fontWeight: 'bold',
      color: 'white',
    },
    content: {
      flex: 1,
      padding: 20,
    },
    sectionHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 12,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: colors.text,
    },
    viewAllButton: {
      padding: 4,
    },
    viewAllText: {
      fontSize: 14,
      color: colors.primary,
      fontWeight: '500',
    },
    coursesContainer: {
      marginBottom: 24,
    },
    coursesList: {
      paddingHorizontal: 0,
    },
    courseCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 16,
      marginRight: 12,
      width: 220,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.05,
      shadowRadius: 3,
      elevation: 2,
    },
    courseHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 8,
    },
    coursePlatform: {
      fontSize: 12,
      color: colors.textSecondary,
      textTransform: 'uppercase',
    },
    courseTitle: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.text,
      marginBottom: 12,
      height: 40,
    },
    progressContainer: {
      flexDirection: 'row',
      alignItems: 'center',
    },
    progressBar: {
      flex: 1,
      height: 6,
      backgroundColor: colors.border,
      borderRadius: 3,
      marginRight: 8,
      overflow: 'hidden',
    },
    progressFill: {
      height: '100%',
      borderRadius: 3,
    },
    progressText: {
      fontSize: 12,
      color: colors.textSecondary,
      width: 36,
      textAlign: 'right',
    },
    deadlinesContainer: {
      flex: 1,
    },
    loadingContainer: {
      padding: 20,
      alignItems: 'center',
      justifyContent: 'center',
    },
    deadlineItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    deadlineCheckbox: {
      width: 22,
      height: 22,
      borderRadius: 4,
      borderWidth: 2,
      borderColor: colors.border,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
    },
    checkmark: {
      color: 'white',
      fontSize: 12,
      fontWeight: 'bold',
    },
    deadlineContent: {
      flex: 1,
      marginRight: 10,
    },
    deadlineTitle: {
      fontSize: 16,
      fontWeight: '500',
      color: colors.text,
      marginBottom: 2,
    },
    deadlineCourse: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    deadlineDate: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    completedText: {
      textDecorationLine: 'line-through',
      color: colors.textSecondary,
    },
    emptyState: {
      padding: 20,
      alignItems: 'center',
      justifyContent: 'center',
    },
    emptyStateText: {
      fontSize: 14,
      color: colors.textSecondary,
      textAlign: 'center',
    },
    navBar: {
      flexDirection: 'row',
      justifyContent: 'space-around',
      backgroundColor: colors.surface,
      paddingVertical: 12,
      borderTopWidth: 1,
      borderTopColor: colors.border,
    },
    navButton: {
      alignItems: 'center',
      padding: 8,
    },
    navText: {
      fontSize: 12,
      color: colors.textSecondary,
      marginTop: 4,
    },
    activeNavText: {
      color: colors.primary,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.welcomeText}>Welcome back,</Text>
        <Text style={styles.userName}>{user?.username || 'User'}</Text>
      </View>
      
      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {/* Courses Section */}
        <View style={styles.coursesContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>My Courses</Text>
            <TouchableOpacity
              style={styles.viewAllButton}
              onPress={() => navigation.navigate('CourseList' as never)}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          {loadingCourses ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator color={colors.primary} />
            </View>
          ) : courses.length > 0 ? (
            <FlatList
              data={courses.slice(0, 5)}
              renderItem={renderCourseItem}
              keyExtractor={(item) => item.id.toString()}
              horizontal
              showsHorizontalScrollIndicator={false}
              style={styles.coursesList}
            />
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>
                You don't have any courses yet. Add courses to get started.
              </Text>
            </View>
          )}
        </View>
        
        {/* Deadlines Section */}
        <View style={styles.deadlinesContainer}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Upcoming Deadlines</Text>
            <TouchableOpacity
              style={styles.viewAllButton}
              onPress={() => navigation.navigate('Deadlines' as never)}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
          
          {loadingDeadlines ? (
            <View style={styles.loadingContainer}>
              <ActivityIndicator color={colors.primary} />
            </View>
          ) : deadlines.length > 0 ? (
            <FlatList
              data={deadlines}
              renderItem={renderDeadlineItem}
              keyExtractor={(item) => item.id.toString()}
              scrollEnabled={false}
            />
          ) : (
            <View style={styles.emptyState}>
              <Text style={styles.emptyStateText}>
                You don't have any upcoming deadlines.
              </Text>
            </View>
          )}
        </View>
      </ScrollView>
      
      {/* Bottom Navigation */}
      <View style={styles.navBar}>
        <TouchableOpacity style={styles.navButton}>
          <Text style={[styles.navText, styles.activeNavText]}>Dashboard</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.navButton}
          onPress={() => navigation.navigate('CourseList' as never)}
        >
          <Text style={styles.navText}>Courses</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.navButton}
          onPress={() => navigation.navigate('Deadlines' as never)}
        >
          <Text style={styles.navText}>Deadlines</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.navButton}
          onPress={() => navigation.navigate('Notes' as never)}
        >
          <Text style={styles.navText}>Notes</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.navButton}
          onPress={() => navigation.navigate('Settings' as never)}
        >
          <Text style={styles.navText}>Settings</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default DashboardScreen;