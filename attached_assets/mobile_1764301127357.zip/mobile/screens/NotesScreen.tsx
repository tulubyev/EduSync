/**
 * Notes Screen Component
 * Displays and manages user's notes
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  TextInput,
  RefreshControl,
  ActivityIndicator,
  Alert,
  Modal,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../components/ThemeProvider';
import { apiService } from '../shared/services/api.service';

// Types
interface Note {
  id: number;
  title: string;
  content: string;
  courseId: number | null;
  courseName: string | null;
  createdAt: string;
  updatedAt: string;
}

interface Course {
  id: number;
  title: string;
}

const NotesScreen: React.FC = () => {
  const navigation = useNavigation();
  const { colors } = useTheme();
  const [notes, setNotes] = useState<Note[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [courseFilter, setCourseFilter] = useState<number | null>(null);
  
  // Add/Edit Note Modal
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [modalMode, setModalMode] = useState<'add' | 'edit'>('add');
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteCourseId, setNoteCourseId] = useState<number | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  // Filter notes when search query or course filter changes
  useEffect(() => {
    // No additional filtering needed as we already have the data
  }, [searchQuery, courseFilter]);

  const loadData = async () => {
    setIsLoading(true);
    try {
      await Promise.all([
        loadNotes(),
        loadCourses(),
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadNotes = async () => {
    try {
      let endpoint = '/api/notes';
      if (courseFilter) {
        endpoint = `/api/notes?courseId=${courseFilter}`;
      }
      
      const response = await apiService.get<Note[]>(endpoint);
      setNotes(response || []);
    } catch (error) {
      console.error('Error loading notes:', error);
      setNotes([]);
    }
  };

  const loadCourses = async () => {
    try {
      const response = await apiService.get<Course[]>('/api/courses');
      setCourses(response || []);
    } catch (error) {
      console.error('Error loading courses:', error);
      setCourses([]);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadData();
    setRefreshing(false);
  };

  // Format date
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Handle note press (view/edit)
  const handleNotePress = (note: Note) => {
    setModalMode('edit');
    setEditingNoteId(note.id);
    setNoteTitle(note.title);
    setNoteContent(note.content);
    setNoteCourseId(note.courseId);
    setIsModalVisible(true);
  };

  // Open add note modal
  const handleAddNote = () => {
    setModalMode('add');
    setEditingNoteId(null);
    setNoteTitle('');
    setNoteContent('');
    setNoteCourseId(null);
    setIsModalVisible(true);
  };

  // Save note (add or update)
  const handleSaveNote = async () => {
    if (!noteTitle.trim()) {
      Alert.alert('Error', 'Note title is required');
      return;
    }
    
    setIsSaving(true);
    
    try {
      if (modalMode === 'add') {
        // Create new note
        await apiService.post('/api/notes', {
          title: noteTitle,
          content: noteContent,
          courseId: noteCourseId,
        });
      } else {
        // Update existing note
        await apiService.patch(`/api/notes/${editingNoteId}`, {
          title: noteTitle,
          content: noteContent,
        });
      }
      
      // Reload notes and close modal
      await loadNotes();
      setIsModalVisible(false);
    } catch (error) {
      console.error('Error saving note:', error);
      Alert.alert('Error', 'Failed to save note. Please try again.');
    } finally {
      setIsSaving(false);
    }
  };

  // Delete note
  const handleDeleteNote = (noteId: number) => {
    Alert.alert(
      'Delete Note',
      'Are you sure you want to delete this note?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await apiService.delete(`/api/notes/${noteId}`);
              // Remove from local state
              setNotes(prev => prev.filter(note => note.id !== noteId));
            } catch (error) {
              console.error('Error deleting note:', error);
              Alert.alert('Error', 'Failed to delete note');
            }
          },
        },
      ]
    );
  };

  // Filter notes by course
  const handleCourseFilter = (courseId: number | null) => {
    setCourseFilter(courseFilter === courseId ? null : courseId);
    loadNotes();
  };

  // Render note card
  const renderNoteItem = ({ item }: { item: Note }) => (
    <TouchableOpacity
      style={styles.noteCard}
      onPress={() => handleNotePress(item)}
      activeOpacity={0.7}
    >
      <View style={styles.noteHeader}>
        <Text style={styles.noteTitle} numberOfLines={1}>
          {item.title}
        </Text>
        <TouchableOpacity
          style={styles.deleteButton}
          onPress={() => handleDeleteNote(item.id)}
        >
          <Text style={styles.deleteButtonText}>×</Text>
        </TouchableOpacity>
      </View>
      
      {item.courseName && (
        <Text style={styles.noteCourse}>{item.courseName}</Text>
      )}
      
      <Text style={styles.noteContent} numberOfLines={3}>
        {item.content}
      </Text>
      
      <Text style={styles.noteDate}>
        {item.updatedAt !== item.createdAt
          ? `Updated: ${formatDate(item.updatedAt)}`
          : `Created: ${formatDate(item.createdAt)}`}
      </Text>
    </TouchableOpacity>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      padding: 16,
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: colors.text,
      marginBottom: 12,
    },
    searchContainer: {
      flexDirection: 'row',
      backgroundColor: colors.background,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: colors.border,
      paddingHorizontal: 12,
      paddingVertical: 8,
    },
    searchInput: {
      flex: 1,
      fontSize: 16,
      color: colors.text,
    },
    content: {
      flex: 1,
      padding: 16,
    },
    filtersContainer: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      paddingVertical: 12,
      paddingHorizontal: 16,
      gap: 8,
    },
    filterButton: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginRight: 8,
      marginBottom: 8,
    },
    filterButtonActive: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    filterText: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    filterTextActive: {
      color: 'white',
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    noteCard: {
      backgroundColor: colors.surface,
      borderRadius: 8,
      padding: 16,
      marginBottom: 16,
      borderLeftWidth: 4,
      borderLeftColor: colors.primary,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 2,
      elevation: 2,
    },
    noteHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 8,
    },
    noteTitle: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.text,
      flex: 1,
    },
    deleteButton: {
      width: 24,
      height: 24,
      borderRadius: 12,
      backgroundColor: colors.surface,
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: 8,
    },
    deleteButtonText: {
      fontSize: 18,
      color: colors.error,
      fontWeight: 'bold',
    },
    noteCourse: {
      fontSize: 12,
      color: colors.primary,
      marginBottom: 8,
    },
    noteContent: {
      fontSize: 14,
      color: colors.textSecondary,
      marginBottom: 8,
      lineHeight: 20,
    },
    noteDate: {
      fontSize: 12,
      color: colors.textSecondary,
      textAlign: 'right',
    },
    emptyState: {
      padding: 40,
      alignItems: 'center',
      justifyContent: 'center',
    },
    emptyStateText: {
      fontSize: 16,
      color: colors.textSecondary,
      textAlign: 'center',
      marginBottom: 16,
    },
    addButton: {
      position: 'absolute',
      right: 16,
      bottom: 16,
      width: 56,
      height: 56,
      borderRadius: 28,
      backgroundColor: colors.primary,
      alignItems: 'center',
      justifyContent: 'center',
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.2,
      shadowRadius: 3,
      elevation: 3,
    },
    addButtonText: {
      fontSize: 24,
      color: 'white',
      fontWeight: 'bold',
    },
    modalContainer: {
      flex: 1,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
      flex: 1,
      backgroundColor: colors.background,
      marginTop: 64,
      borderTopLeftRadius: 16,
      borderTopRightRadius: 16,
      padding: 16,
    },
    modalHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 16,
    },
    modalTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: colors.text,
    },
    closeButton: {
      padding: 8,
    },
    closeButtonText: {
      fontSize: 16,
      color: colors.textSecondary,
    },
    formGroup: {
      marginBottom: 16,
    },
    label: {
      fontSize: 14,
      fontWeight: '500',
      color: colors.text,
      marginBottom: 8,
    },
    input: {
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 8,
      padding: 12,
      fontSize: 16,
      color: colors.text,
    },
    textArea: {
      minHeight: 120,
      textAlignVertical: 'top',
    },
    coursePicker: {
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 8,
      padding: 12,
    },
    courseOptions: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      marginTop: 8,
      gap: 8,
    },
    courseOption: {
      paddingHorizontal: 12,
      paddingVertical: 6,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.border,
      marginRight: 8,
      marginBottom: 8,
    },
    courseOptionSelected: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    courseOptionText: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    courseOptionTextSelected: {
      color: 'white',
    },
    saveButton: {
      backgroundColor: colors.primary,
      borderRadius: 8,
      padding: 16,
      alignItems: 'center',
      marginTop: 24,
    },
    saveButtonText: {
      color: 'white',
      fontSize: 16,
      fontWeight: '600',
    },
    backButton: {
      paddingVertical: 8,
      paddingHorizontal: 16,
      marginBottom: 8,
    },
    backButtonText: {
      fontSize: 16,
      color: colors.primary,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        
        <Text style={styles.headerTitle}>My Notes</Text>
        
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search notes..."
            placeholderTextColor={colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>
      
      {courses.length > 0 && (
        <View style={styles.filtersContainer}>
          {courses.map(course => (
            <TouchableOpacity
              key={course.id}
              style={[
                styles.filterButton,
                courseFilter === course.id && styles.filterButtonActive,
              ]}
              onPress={() => handleCourseFilter(course.id)}
            >
              <Text
                style={[
                  styles.filterText,
                  courseFilter === course.id && styles.filterTextActive,
                ]}
                numberOfLines={1}
              >
                {course.title}
              </Text>
            </TouchableOpacity>
          ))}
          
          {courseFilter && (
            <TouchableOpacity
              style={styles.filterButton}
              onPress={() => handleCourseFilter(null)}
            >
              <Text style={styles.filterText}>Clear Filter</Text>
            </TouchableOpacity>
          )}
        </View>
      )}
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : notes.length > 0 ? (
        <FlatList
          data={notes.filter(note => 
            searchQuery 
              ? note.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
                note.content.toLowerCase().includes(searchQuery.toLowerCase())
              : true
          )}
          renderItem={renderNoteItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.content}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      ) : (
        <View style={styles.emptyState}>
          <Text style={styles.emptyStateText}>
            {courseFilter
              ? 'No notes found for this course. Add your first note!'
              : 'You don\'t have any notes yet. Add your first note!'}
          </Text>
        </View>
      )}
      
      {/* Add Note Button */}
      <TouchableOpacity style={styles.addButton} onPress={handleAddNote}>
        <Text style={styles.addButtonText}>+</Text>
      </TouchableOpacity>
      
      {/* Add/Edit Note Modal */}
      <Modal
        visible={isModalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setIsModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>
                {modalMode === 'add' ? 'Add Note' : 'Edit Note'}
              </Text>
              <TouchableOpacity
                style={styles.closeButton}
                onPress={() => setIsModalVisible(false)}
              >
                <Text style={styles.closeButtonText}>Cancel</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>Title</Text>
              <TextInput
                style={styles.input}
                value={noteTitle}
                onChangeText={setNoteTitle}
                placeholder="Note title"
                placeholderTextColor={colors.textSecondary}
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>Content</Text>
              <TextInput
                style={[styles.input, styles.textArea]}
                value={noteContent}
                onChangeText={setNoteContent}
                placeholder="Write your note here..."
                placeholderTextColor={colors.textSecondary}
                multiline
                textAlignVertical="top"
              />
            </View>
            
            {modalMode === 'add' && (
              <View style={styles.formGroup}>
                <Text style={styles.label}>Course (Optional)</Text>
                <View style={styles.courseOptions}>
                  {courses.map(course => (
                    <TouchableOpacity
                      key={course.id}
                      style={[
                        styles.courseOption,
                        noteCourseId === course.id && styles.courseOptionSelected,
                      ]}
                      onPress={() => setNoteCourseId(
                        noteCourseId === course.id ? null : course.id
                      )}
                    >
                      <Text
                        style={[
                          styles.courseOptionText,
                          noteCourseId === course.id && styles.courseOptionTextSelected,
                        ]}
                        numberOfLines={1}
                      >
                        {course.title}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
            )}
            
            <TouchableOpacity
              style={styles.saveButton}
              onPress={handleSaveNote}
              disabled={isSaving}
            >
              {isSaving ? (
                <ActivityIndicator color="white" size="small" />
              ) : (
                <Text style={styles.saveButtonText}>Save</Text>
              )}
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default NotesScreen;