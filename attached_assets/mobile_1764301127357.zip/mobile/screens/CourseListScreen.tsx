/**
 * Course List Screen Component
 * Displays all user's courses
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  RefreshControl,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTheme } from '../components/ThemeProvider';
import { apiService } from '../shared/services/api.service';

// Types
interface Course {
  id: number;
  title: string;
  platform: string;
  progress: number;
  status: string;
  imageUrl?: string;
  description?: string;
}

const CourseListScreen: React.FC = () => {
  const navigation = useNavigation();
  const { colors } = useTheme();
  const [courses, setCourses] = useState<Course[]>([]);
  const [filteredCourses, setFilteredCourses] = useState<Course[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string | null>(null);

  // Load courses
  useEffect(() => {
    loadCourses();
  }, []);

  // Filter courses when search query or status filter changes
  useEffect(() => {
    let result = courses;
    
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      result = result.filter(
        course => 
          course.title.toLowerCase().includes(query) ||
          course.platform.toLowerCase().includes(query)
      );
    }
    
    if (statusFilter) {
      result = result.filter(course => course.status === statusFilter);
    }
    
    setFilteredCourses(result);
  }, [courses, searchQuery, statusFilter]);

  const loadCourses = async () => {
    setIsLoading(true);
    try {
      const response = await apiService.get<Course[]>('/api/courses');
      setCourses(response || []);
      setFilteredCourses(response || []);
    } catch (error) {
      console.error('Error loading courses:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadCourses();
    setRefreshing(false);
  };

  const handleCoursePress = (courseId: number) => {
    navigation.navigate('CourseDetail' as never, { courseId } as never);
  };

  const renderCourseItem = ({ item }: { item: Course }) => (
    <TouchableOpacity
      style={styles.courseCard}
      onPress={() => handleCoursePress(item.id)}
    >
      <View style={styles.courseHeader}>
        <Text style={styles.coursePlatform}>{item.platform}</Text>
        <View
          style={[
            styles.statusBadge,
            {
              backgroundColor:
                item.status === 'active'
                  ? 'rgba(16, 185, 129, 0.1)'
                  : item.status === 'completed'
                    ? 'rgba(59, 130, 246, 0.1)'
                    : 'rgba(156, 163, 175, 0.1)',
              borderColor:
                item.status === 'active'
                  ? colors.secondary
                  : item.status === 'completed'
                    ? colors.primary
                    : colors.textSecondary,
            },
          ]}
        >
          <Text
            style={[
              styles.statusText,
              {
                color:
                  item.status === 'active'
                    ? colors.secondary
                    : item.status === 'completed'
                      ? colors.primary
                      : colors.textSecondary,
              },
            ]}
          >
            {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
          </Text>
        </View>
      </View>
      
      <Text style={styles.courseTitle} numberOfLines={2}>
        {item.title}
      </Text>
      
      {item.description && (
        <Text style={styles.courseDescription} numberOfLines={2}>
          {item.description}
        </Text>
      )}
      
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <View
            style={[
              styles.progressFill,
              { width: `${item.progress}%`, backgroundColor: colors.primary },
            ]}
          />
        </View>
        <Text style={styles.progressText}>{item.progress}%</Text>
      </View>
    </TouchableOpacity>
  );

  const handleStatusFilter = (status: string | null) => {
    setStatusFilter(statusFilter === status ? null : status);
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      padding: 16,
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: colors.text,
      marginBottom: 12,
    },
    searchContainer: {
      flexDirection: 'row',
      backgroundColor: colors.background,
      borderRadius: 8,
      borderWidth: 1,
      borderColor: colors.border,
      paddingHorizontal: 12,
      paddingVertical: 8,
    },
    searchInput: {
      flex: 1,
      fontSize: 16,
      color: colors.text,
    },
    filtersContainer: {
      flexDirection: 'row',
      paddingVertical: 12,
      paddingHorizontal: 16,
      gap: 8,
    },
    filterButton: {
      paddingHorizontal: 16,
      paddingVertical: 6,
      borderRadius: 16,
      borderWidth: 1,
      borderColor: colors.border,
    },
    filterButtonActive: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    filterText: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    filterTextActive: {
      color: 'white',
    },
    content: {
      flex: 1,
      padding: 16,
    },
    courseCard: {
      backgroundColor: colors.surface,
      borderRadius: 12,
      padding: 16,
      marginBottom: 16,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 1 },
      shadowOpacity: 0.05,
      shadowRadius: 2,
      elevation: 2,
    },
    courseHeader: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      marginBottom: 8,
    },
    statusBadge: {
      paddingHorizontal: 8,
      paddingVertical: 2,
      borderRadius: 4,
      borderWidth: 1,
    },
    statusText: {
      fontSize: 10,
      fontWeight: '500',
    },
    coursePlatform: {
      fontSize: 12,
      color: colors.textSecondary,
      textTransform: 'uppercase',
    },
    courseTitle: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.text,
      marginBottom: 8,
    },
    courseDescription: {
      fontSize: 14,
      color: colors.textSecondary,
      marginBottom: 16,
    },
    progressContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginTop: 8,
    },
    progressBar: {
      flex: 1,
      height: 6,
      backgroundColor: colors.border,
      borderRadius: 3,
      marginRight: 8,
      overflow: 'hidden',
    },
    progressFill: {
      height: '100%',
      borderRadius: 3,
    },
    progressText: {
      fontSize: 12,
      color: colors.textSecondary,
      width: 36,
      textAlign: 'right',
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    emptyContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      padding: 20,
    },
    emptyText: {
      fontSize: 16,
      color: colors.textSecondary,
      textAlign: 'center',
    },
    backButton: {
      paddingVertical: 8,
      paddingHorizontal: 16,
      marginBottom: 8,
    },
    backButtonText: {
      fontSize: 16,
      color: colors.primary,
    },
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        
        <Text style={styles.headerTitle}>My Courses</Text>
        
        <View style={styles.searchContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="Search courses..."
            placeholderTextColor={colors.textSecondary}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
      </View>
      
      <View style={styles.filtersContainer}>
        <TouchableOpacity
          style={[
            styles.filterButton,
            statusFilter === 'active' && styles.filterButtonActive,
          ]}
          onPress={() => handleStatusFilter('active')}
        >
          <Text
            style={[
              styles.filterText,
              statusFilter === 'active' && styles.filterTextActive,
            ]}
          >
            Active
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.filterButton,
            statusFilter === 'completed' && styles.filterButtonActive,
          ]}
          onPress={() => handleStatusFilter('completed')}
        >
          <Text
            style={[
              styles.filterText,
              statusFilter === 'completed' && styles.filterTextActive,
            ]}
          >
            Completed
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[
            styles.filterButton,
            statusFilter === 'paused' && styles.filterButtonActive,
          ]}
          onPress={() => handleStatusFilter('paused')}
        >
          <Text
            style={[
              styles.filterText,
              statusFilter === 'paused' && styles.filterTextActive,
            ]}
          >
            Paused
          </Text>
        </TouchableOpacity>
      </View>
      
      {isLoading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      ) : filteredCourses.length > 0 ? (
        <FlatList
          data={filteredCourses}
          renderItem={renderCourseItem}
          keyExtractor={(item) => item.id.toString()}
          contentContainerStyle={styles.content}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
        />
      ) : (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>
            {searchQuery || statusFilter
              ? 'No courses match your filters. Try a different search or filter.'
              : 'You don\'t have any courses yet. Connect to learning platforms or add courses manually.'}
          </Text>
        </View>
      )}
    </View>
  );
};

export default CourseListScreen;