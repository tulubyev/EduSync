/**
 * Settings Screen Component
 * Manages user settings and preferences
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  ActivityIndicator,
  Modal,
  TextInput,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useTheme, ThemePreference } from '../components/ThemeProvider';
import { authService } from '../shared/services/auth.service';
import { apiService } from '../shared/services/api.service';
import { storageService } from '../shared/services/storage.service';

// Types
interface NotificationPreferences {
  deadlineReminders: boolean;
  courseUpdates: boolean;
  platformNotifications: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
}

interface User {
  id: number;
  username: string;
  email: string;
  fullName?: string;
  profileImage?: string;
}

const SettingsScreen: React.FC = () => {
  const navigation = useNavigation();
  const { colors, theme, setTheme } = useTheme();
  
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSaving, setIsSaving] = useState(false);
  
  // Notification preferences
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>({
    deadlineReminders: true,
    courseUpdates: true,
    platformNotifications: true,
    emailNotifications: true,
    pushNotifications: true,
  });
  
  // Theme settings
  const [themeType, setThemeType] = useState<'light' | 'dark' | 'system'>(
    theme.themeType as 'light' | 'dark' | 'system'
  );
  
  // Change password modal
  const [passwordModalVisible, setPasswordModalVisible] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [changingPassword, setChangingPassword] = useState(false);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    setIsLoading(true);
    try {
      // Get current user
      const userData = authService.getUser();
      setUser(userData);
      
      // Load notification preferences
      try {
        const notificationSettings = await apiService.get<NotificationPreferences>('/api/notifications/preferences');
        if (notificationSettings) {
          setNotificationPrefs(notificationSettings);
        }
      } catch (error) {
        console.error('Error loading notification preferences:', error);
      }
    } catch (error) {
      console.error('Error loading user data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  // Handle theme change
  const handleThemeChange = (newThemeType: 'light' | 'dark' | 'system') => {
    setThemeType(newThemeType);
    
    // Save to theme provider and storage
    const newTheme: ThemePreference = {
      ...theme,
      themeType: newThemeType,
    };
    
    setTheme(newTheme);
    
    // Sync with server
    apiService.patch('/api/users/theme', { themeType: newThemeType })
      .catch(error => console.error('Error saving theme preference:', error));
  };

  // Handle notification preference toggle
  const toggleNotificationPref = (key: keyof NotificationPreferences) => {
    const updatedPrefs = {
      ...notificationPrefs,
      [key]: !notificationPrefs[key],
    };
    
    setNotificationPrefs(updatedPrefs);
    
    // Sync with server (debounced)
    apiService.patch('/api/notifications/preferences', { [key]: updatedPrefs[key] })
      .catch(error => console.error('Error saving notification preference:', error));
  };

  // Handle password change
  const handleChangePassword = async () => {
    // Validate inputs
    if (!currentPassword) {
      Alert.alert('Error', 'Current password is required');
      return;
    }
    
    if (!newPassword) {
      Alert.alert('Error', 'New password is required');
      return;
    }
    
    if (newPassword.length < 6) {
      Alert.alert('Error', 'New password must be at least 6 characters');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }
    
    setChangingPassword(true);
    
    try {
      await apiService.post('/api/auth/change-password', {
        currentPassword,
        newPassword,
      });
      
      // Success
      Alert.alert('Success', 'Your password has been updated');
      setPasswordModalVisible(false);
      
      // Reset form
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (error) {
      console.error('Error changing password:', error);
      Alert.alert('Error', 'Failed to change password. Please check your current password and try again.');
    } finally {
      setChangingPassword(false);
    }
  };

  // Handle logout
  const handleLogout = async () => {
    Alert.alert(
      'Confirm Logout',
      'Are you sure you want to log out?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await authService.logout();
            } catch (error) {
              console.error('Error logging out:', error);
            }
          },
        },
      ]
    );
  };

  // Handle clear local data
  const handleClearData = () => {
    Alert.alert(
      'Clear Local Data',
      'This will clear all cached data. Your account will not be deleted. Continue?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Clear Data',
          style: 'destructive',
          onPress: async () => {
            try {
              await storageService.clear();
              Alert.alert(
                'Data Cleared',
                'All local data has been cleared. The app will now reload.',
                [
                  {
                    text: 'OK',
                    onPress: () => {
                      // In a real app, we would reload the app here
                      // or navigate to the login screen
                      authService.logout();
                    },
                  },
                ]
              );
            } catch (error) {
              console.error('Error clearing data:', error);
              Alert.alert('Error', 'Failed to clear data');
            }
          },
        },
      ]
    );
  };

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    header: {
      padding: 16,
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    headerTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: colors.text,
      marginBottom: 4,
    },
    backButton: {
      paddingVertical: 8,
      marginBottom: 8,
    },
    backButtonText: {
      fontSize: 16,
      color: colors.primary,
    },
    content: {
      flex: 1,
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    section: {
      marginBottom: 24,
      padding: 16,
      backgroundColor: colors.surface,
      borderTopWidth: 1,
      borderBottomWidth: 1,
      borderColor: colors.border,
    },
    sectionHeader: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.text,
      marginBottom: 16,
    },
    profileSection: {
      alignItems: 'center',
      paddingVertical: 24,
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    avatar: {
      width: 80,
      height: 80,
      borderRadius: 40,
      backgroundColor: colors.primary,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 16,
    },
    avatarText: {
      fontSize: 32,
      fontWeight: 'bold',
      color: 'white',
    },
    userName: {
      fontSize: 18,
      fontWeight: '600',
      color: colors.text,
      marginBottom: 4,
    },
    userEmail: {
      fontSize: 14,
      color: colors.textSecondary,
    },
    editProfileButton: {
      marginTop: 16,
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 16,
    },
    editProfileText: {
      fontSize: 14,
      color: colors.primary,
    },
    row: {
      flexDirection: 'row',
      justifyContent: 'space-between',
      alignItems: 'center',
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    lastRow: {
      borderBottomWidth: 0,
    },
    rowLabel: {
      fontSize: 16,
      color: colors.text,
    },
    rowDescription: {
      fontSize: 12,
      color: colors.textSecondary,
      marginTop: 2,
    },
    themeOptions: {
      flexDirection: 'row',
      marginTop: 8,
    },
    themeOption: {
      flex: 1,
      padding: 8,
      alignItems: 'center',
      borderWidth: 1,
      borderColor: colors.border,
    },
    themeOptionFirst: {
      borderTopLeftRadius: 4,
      borderBottomLeftRadius: 4,
    },
    themeOptionMiddle: {
      borderLeftWidth: 0,
      borderRightWidth: 0,
    },
    themeOptionLast: {
      borderTopRightRadius: 4,
      borderBottomRightRadius: 4,
    },
    themeOptionSelected: {
      backgroundColor: colors.primary,
      borderColor: colors.primary,
    },
    themeOptionText: {
      fontSize: 14,
      color: colors.textSecondary,
    },
    themeOptionTextSelected: {
      color: 'white',
      fontWeight: '500',
    },
    actionButton: {
      paddingVertical: 16,
      paddingHorizontal: 16,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    actionButtonText: {
      fontSize: 16,
      color: colors.text,
    },
    dangerText: {
      color: colors.error,
    },
    version: {
      padding: 16,
      alignItems: 'center',
    },
    versionText: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    modalContainer: {
      flex: 1,
      justifyContent: 'center',
      padding: 16,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
    },
    modalContent: {
      backgroundColor: colors.background,
      borderRadius: 8,
      padding: 16,
      shadowColor: '#000',
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.25,
      shadowRadius: 3.84,
      elevation: 5,
    },
    modalTitle: {
      fontSize: 18,
      fontWeight: 'bold',
      color: colors.text,
      marginBottom: 16,
    },
    formGroup: {
      marginBottom: 16,
    },
    label: {
      fontSize: 14,
      fontWeight: '500',
      color: colors.text,
      marginBottom: 8,
    },
    input: {
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 8,
      padding: 12,
      fontSize: 16,
      color: colors.text,
    },
    modalActions: {
      flexDirection: 'row',
      justifyContent: 'flex-end',
      marginTop: 16,
    },
    modalButton: {
      paddingHorizontal: 16,
      paddingVertical: 8,
      borderRadius: 4,
      marginLeft: 8,
    },
    cancelButton: {
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
    },
    saveButton: {
      backgroundColor: colors.primary,
    },
    modalButtonText: {
      fontSize: 14,
      fontWeight: '500',
    },
    cancelButtonText: {
      color: colors.text,
    },
    saveButtonText: {
      color: 'white',
    },
  });

  if (isLoading) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Settings</Text>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.primary} />
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Settings</Text>
      </View>
      
      <ScrollView style={styles.content}>
        {/* Profile Section */}
        <View style={styles.profileSection}>
          <View style={styles.avatar}>
            <Text style={styles.avatarText}>
              {user?.username ? user.username.charAt(0).toUpperCase() : 'U'}
            </Text>
          </View>
          <Text style={styles.userName}>
            {user?.fullName || user?.username || 'User'}
          </Text>
          <Text style={styles.userEmail}>{user?.email || ''}</Text>
          
          <TouchableOpacity style={styles.editProfileButton}>
            <Text style={styles.editProfileText}>Edit Profile</Text>
          </TouchableOpacity>
        </View>
        
        {/* Theme Section */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>Appearance</Text>
          
          <View style={styles.themeOptions}>
            <TouchableOpacity
              style={[
                styles.themeOption,
                styles.themeOptionFirst,
                themeType === 'light' && styles.themeOptionSelected,
              ]}
              onPress={() => handleThemeChange('light')}
            >
              <Text
                style={[
                  styles.themeOptionText,
                  themeType === 'light' && styles.themeOptionTextSelected,
                ]}
              >
                Light
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.themeOption,
                styles.themeOptionMiddle,
                themeType === 'dark' && styles.themeOptionSelected,
              ]}
              onPress={() => handleThemeChange('dark')}
            >
              <Text
                style={[
                  styles.themeOptionText,
                  themeType === 'dark' && styles.themeOptionTextSelected,
                ]}
              >
                Dark
              </Text>
            </TouchableOpacity>
            
            <TouchableOpacity
              style={[
                styles.themeOption,
                styles.themeOptionLast,
                themeType === 'system' && styles.themeOptionSelected,
              ]}
              onPress={() => handleThemeChange('system')}
            >
              <Text
                style={[
                  styles.themeOptionText,
                  themeType === 'system' && styles.themeOptionTextSelected,
                ]}
              >
                System
              </Text>
            </TouchableOpacity>
          </View>
        </View>
        
        {/* Notifications Section */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>Notifications</Text>
          
          <View style={styles.row}>
            <View>
              <Text style={styles.rowLabel}>Deadline Reminders</Text>
              <Text style={styles.rowDescription}>Get notified about upcoming deadlines</Text>
            </View>
            <Switch
              value={notificationPrefs.deadlineReminders}
              onValueChange={() => toggleNotificationPref('deadlineReminders')}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="white"
            />
          </View>
          
          <View style={styles.row}>
            <View>
              <Text style={styles.rowLabel}>Course Updates</Text>
              <Text style={styles.rowDescription}>Get notified about course content updates</Text>
            </View>
            <Switch
              value={notificationPrefs.courseUpdates}
              onValueChange={() => toggleNotificationPref('courseUpdates')}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="white"
            />
          </View>
          
          <View style={styles.row}>
            <View>
              <Text style={styles.rowLabel}>Platform Notifications</Text>
              <Text style={styles.rowDescription}>Get notifications from connected platforms</Text>
            </View>
            <Switch
              value={notificationPrefs.platformNotifications}
              onValueChange={() => toggleNotificationPref('platformNotifications')}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="white"
            />
          </View>
          
          <View style={styles.row}>
            <View>
              <Text style={styles.rowLabel}>Email Notifications</Text>
              <Text style={styles.rowDescription}>Receive notifications via email</Text>
            </View>
            <Switch
              value={notificationPrefs.emailNotifications}
              onValueChange={() => toggleNotificationPref('emailNotifications')}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="white"
            />
          </View>
          
          <View style={[styles.row, styles.lastRow]}>
            <View>
              <Text style={styles.rowLabel}>Push Notifications</Text>
              <Text style={styles.rowDescription}>Receive push notifications on this device</Text>
            </View>
            <Switch
              value={notificationPrefs.pushNotifications}
              onValueChange={() => toggleNotificationPref('pushNotifications')}
              trackColor={{ false: colors.border, true: colors.primary }}
              thumbColor="white"
            />
          </View>
        </View>
        
        {/* Account Section */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>Account</Text>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => setPasswordModalVisible(true)}
          >
            <Text style={styles.actionButtonText}>Change Password</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={handleClearData}
          >
            <Text style={styles.actionButtonText}>Clear Cache</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, { borderBottomWidth: 0 }]}
            onPress={handleLogout}
          >
            <Text style={[styles.actionButtonText, styles.dangerText]}>Logout</Text>
          </TouchableOpacity>
        </View>
        
        {/* About Section */}
        <View style={styles.section}>
          <Text style={styles.sectionHeader}>About</Text>
          
          <TouchableOpacity style={styles.actionButton}>
            <Text style={styles.actionButtonText}>Privacy Policy</Text>
          </TouchableOpacity>
          
          <TouchableOpacity style={styles.actionButton}>
            <Text style={styles.actionButtonText}>Terms of Service</Text>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={[styles.actionButton, { borderBottomWidth: 0 }]}
          >
            <Text style={styles.actionButtonText}>Help & Support</Text>
          </TouchableOpacity>
        </View>
        
        <View style={styles.version}>
          <Text style={styles.versionText}>Version 1.0.0</Text>
        </View>
      </ScrollView>
      
      {/* Change Password Modal */}
      <Modal
        visible={passwordModalVisible}
        transparent={true}
        animationType="fade"
        onRequestClose={() => setPasswordModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Change Password</Text>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>Current Password</Text>
              <TextInput
                style={styles.input}
                value={currentPassword}
                onChangeText={setCurrentPassword}
                placeholder="Enter current password"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>New Password</Text>
              <TextInput
                style={styles.input}
                value={newPassword}
                onChangeText={setNewPassword}
                placeholder="Enter new password"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry
              />
            </View>
            
            <View style={styles.formGroup}>
              <Text style={styles.label}>Confirm New Password</Text>
              <TextInput
                style={styles.input}
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                placeholder="Confirm new password"
                placeholderTextColor={colors.textSecondary}
                secureTextEntry
              />
            </View>
            
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setPasswordModalVisible(false)}
                disabled={changingPassword}
              >
                <Text style={[styles.modalButtonText, styles.cancelButtonText]}>
                  Cancel
                </Text>
              </TouchableOpacity>
              
              <TouchableOpacity
                style={[styles.modalButton, styles.saveButton]}
                onPress={handleChangePassword}
                disabled={changingPassword}
              >
                {changingPassword ? (
                  <ActivityIndicator size="small" color="white" />
                ) : (
                  <Text style={[styles.modalButtonText, styles.saveButtonText]}>
                    Change
                  </Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

export default SettingsScreen;