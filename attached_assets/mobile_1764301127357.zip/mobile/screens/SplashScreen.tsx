/**
 * Splash Screen Component
 * Initial loading screen for the mobile app
 */
import React from 'react';
import { View, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useTheme } from '../components/ThemeProvider';

const SplashScreen: React.FC = () => {
  const { colors } = useTheme();

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
      backgroundColor: colors.background,
    },
    logo: {
      fontSize: 32,
      fontWeight: 'bold',
      color: colors.primary,
      marginBottom: 20,
    },
    subtitle: {
      fontSize: 18,
      color: colors.textSecondary,
      marginBottom: 40,
    },
    loadingText: {
      fontSize: 14,
      color: colors.textSecondary,
      marginTop: 20,
    },
  });

  return (
    <View style={styles.container}>
      <Text style={styles.logo}>EduAggregator</Text>
      <Text style={styles.subtitle}>Your courses in one place</Text>
      <ActivityIndicator size="large" color={colors.primary} />
      <Text style={styles.loadingText}>Loading...</Text>
    </View>
  );
};

export default SplashScreen;