/**
 * Course Detail Screen Component
 * Displays a specific course with its details
 */
import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  FlatList,
} from 'react-native';
import { useRoute, useNavigation, RouteProp } from '@react-navigation/native';
import { useTheme } from '../components/ThemeProvider';
import { apiService } from '../shared/services/api.service';

// Types
type CourseDetailRouteParams = {
  courseId: number;
};

interface Course {
  id: number;
  title: string;
  description: string;
  platform: string;
  instructor: string;
  startDate: string;
  endDate: string | null;
  status: string;
  progress: number;
  imageUrl: string | null;
  url: string | null;
}

interface Deadline {
  id: number;
  title: string;
  dueDate: string;
  completed: boolean;
}

interface Session {
  id: number;
  title: string;
  startTime: string;
  endTime: string;
  recurring: boolean;
  recurringPattern: string | null;
}

const CourseDetailScreen: React.FC = () => {
  const route = useRoute() as RouteProp<Record<string, CourseDetailRouteParams>, string>;
  const navigation = useNavigation();
  const { colors } = useTheme();
  const { courseId } = route.params;
  
  const [course, setCourse] = useState<Course | null>(null);
  const [deadlines, setDeadlines] = useState<Deadline[]>([]);
  const [sessions, setSessions] = useState<Session[]>([]);
  const [activeTab, setActiveTab] = useState('overview');
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadCourseData();
  }, [courseId]);

  const loadCourseData = async () => {
    setIsLoading(true);
    try {
      const courseData = await apiService.get<Course>(`/api/courses/${courseId}`);
      setCourse(courseData);
      
      // Load related data
      const deadlinesData = await apiService.get<Deadline[]>(`/api/courses/${courseId}/deadlines`);
      setDeadlines(deadlinesData || []);
      
      const sessionsData = await apiService.get<Session[]>(`/api/courses/${courseId}/sessions`);
      setSessions(sessionsData || []);
    } catch (error) {
      console.error('Error loading course data:', error);
      Alert.alert('Error', 'Failed to load course details');
    } finally {
      setIsLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadCourseData();
    setRefreshing(false);
  };

  // Format date
  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  // Format time
  const formatTime = (dateString: string) => {
    if (!dateString) return 'N/A';
    
    const date = new Date(dateString);
    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  // Update course progress
  const updateProgress = async (newProgress: number) => {
    try {
      await apiService.patch(`/api/courses/${courseId}/progress`, {
        progress: newProgress,
      });
      
      setCourse(prev => {
        if (!prev) return null;
        return { ...prev, progress: newProgress };
      });
    } catch (error) {
      console.error('Error updating progress:', error);
      Alert.alert('Error', 'Failed to update course progress');
    }
  };

  // Toggle deadline completion
  const toggleDeadlineCompletion = async (deadlineId: number, completed: boolean) => {
    try {
      await apiService.patch(`/api/deadlines/${deadlineId}/complete`, {
        completed: !completed,
      });
      
      setDeadlines(prevDeadlines =>
        prevDeadlines.map(deadline =>
          deadline.id === deadlineId
            ? { ...deadline, completed: !completed }
            : deadline
        )
      );
    } catch (error) {
      console.error('Error updating deadline:', error);
      Alert.alert('Error', 'Failed to update deadline status');
    }
  };

  const renderDeadlineItem = ({ item }: { item: Deadline }) => (
    <View style={styles.deadlineItem}>
      <TouchableOpacity
        style={[
          styles.deadlineCheckbox,
          item.completed && { backgroundColor: colors.primary, borderColor: colors.primary },
        ]}
        onPress={() => toggleDeadlineCompletion(item.id, item.completed)}
      >
        {item.completed && <Text style={styles.checkmark}>✓</Text>}
      </TouchableOpacity>
      <View style={styles.deadlineContent}>
        <Text
          style={[
            styles.deadlineTitle,
            item.completed && styles.completedText,
          ]}
        >
          {item.title}
        </Text>
        <Text style={styles.deadlineDate}>{formatDate(item.dueDate)}</Text>
      </View>
    </View>
  );

  const renderSessionItem = ({ item }: { item: Session }) => (
    <View style={styles.sessionItem}>
      <View style={styles.sessionTimeContainer}>
        <Text style={styles.sessionTime}>{formatTime(item.startTime)}</Text>
        <Text style={styles.sessionTimeSeparator}>-</Text>
        <Text style={styles.sessionTime}>{formatTime(item.endTime)}</Text>
      </View>
      <View style={styles.sessionContent}>
        <Text style={styles.sessionTitle}>{item.title}</Text>
        {item.recurring && (
          <Text style={styles.sessionRecurring}>
            {item.recurringPattern || 'Recurring'}
          </Text>
        )}
      </View>
    </View>
  );

  const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: colors.background,
    },
    loadingContainer: {
      flex: 1,
      justifyContent: 'center',
      alignItems: 'center',
    },
    header: {
      padding: 16,
      backgroundColor: colors.primary,
    },
    backButton: {
      paddingVertical: 8,
      marginBottom: 8,
    },
    backButtonText: {
      fontSize: 16,
      color: 'white',
      opacity: 0.9,
    },
    courseTitle: {
      fontSize: 20,
      fontWeight: 'bold',
      color: 'white',
      marginBottom: 4,
    },
    coursePlatform: {
      fontSize: 14,
      color: 'white',
      opacity: 0.8,
    },
    content: {
      flex: 1,
    },
    progressSection: {
      padding: 16,
      backgroundColor: colors.surface,
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
    },
    progressContainer: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 12,
    },
    progressBar: {
      flex: 1,
      height: 8,
      backgroundColor: colors.border,
      borderRadius: 4,
      marginRight: 16,
      overflow: 'hidden',
    },
    progressFill: {
      height: '100%',
      borderRadius: 4,
    },
    progressText: {
      fontSize: 16,
      fontWeight: '600',
      color: colors.text,
      width: 45,
      textAlign: 'right',
    },
    progressControls: {
      flexDirection: 'row',
      justifyContent: 'space-between',
    },
    progressButton: {
      backgroundColor: colors.surface,
      borderWidth: 1,
      borderColor: colors.border,
      borderRadius: 4,
      paddingVertical: 6,
      paddingHorizontal: 12,
    },
    progressButtonText: {
      fontSize: 12,
      color: colors.text,
    },
    tabsContainer: {
      flexDirection: 'row',
      borderBottomWidth: 1,
      borderBottomColor: colors.border,
      backgroundColor: colors.surface,
    },
    tab: {
      flex: 1,
      paddingVertical: 12,
      alignItems: 'center',
    },
    activeTab: {
      borderBottomWidth: 2,
      borderBottomColor: colors.primary,
    },
    tabText: {
      fontSize: 14,
      color: colors.textSecondary,
    },
    activeTabText: {
      color: colors.primary,
      fontWeight: '500',
    },
    tabContent: {
      padding: 16,
    },
    sectionTitle: {
      fontSize: 18,
      fontWeight: '600',
      color: colors.text,
      marginBottom: 16,
    },
    infoRow: {
      flexDirection: 'row',
      marginBottom: 12,
    },
    infoLabel: {
      width: 100,
      fontSize: 14,
      color: colors.textSecondary,
    },
    infoValue: {
      flex: 1,
      fontSize: 14,
      color: colors.text,
    },
    description: {
      fontSize: 14,
      lineHeight: 20,
      color: colors.text,
      marginBottom: 16,
    },
    linkButton: {
      backgroundColor: colors.primary,
      borderRadius: 4,
      paddingVertical: 8,
      paddingHorizontal: 16,
      alignSelf: 'flex-start',
      marginTop: 8,
    },
    linkButtonText: {
      color: 'white',
      fontSize: 14,
      fontWeight: '500',
    },
    statusBadge: {
      paddingHorizontal: 10,
      paddingVertical: 4,
      borderRadius: 4,
      alignSelf: 'flex-start',
      marginTop: 16,
      marginBottom: 16,
    },
    statusText: {
      fontSize: 12,
      fontWeight: '500',
    },
    deadlineItem: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    deadlineCheckbox: {
      width: 22,
      height: 22,
      borderRadius: 4,
      borderWidth: 2,
      borderColor: colors.border,
      alignItems: 'center',
      justifyContent: 'center',
      marginRight: 12,
    },
    checkmark: {
      color: 'white',
      fontSize: 12,
      fontWeight: 'bold',
    },
    deadlineContent: {
      flex: 1,
    },
    deadlineTitle: {
      fontSize: 14,
      fontWeight: '500',
      color: colors.text,
      marginBottom: 2,
    },
    deadlineDate: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    completedText: {
      textDecorationLine: 'line-through',
      color: colors.textSecondary,
    },
    sessionItem: {
      flexDirection: 'row',
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: colors.divider,
    },
    sessionTimeContainer: {
      width: 100,
    },
    sessionTime: {
      fontSize: 12,
      color: colors.textSecondary,
    },
    sessionTimeSeparator: {
      fontSize: 12,
      color: colors.textSecondary,
      textAlign: 'center',
    },
    sessionContent: {
      flex: 1,
    },
    sessionTitle: {
      fontSize: 14,
      fontWeight: '500',
      color: colors.text,
      marginBottom: 2,
    },
    sessionRecurring: {
      fontSize: 12,
      color: colors.primary,
    },
    emptyState: {
      padding: 20,
      alignItems: 'center',
      justifyContent: 'center',
    },
    emptyStateText: {
      fontSize: 14,
      color: colors.textSecondary,
      textAlign: 'center',
    },
  });

  if (isLoading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={colors.primary} />
      </View>
    );
  }

  if (!course) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => navigation.goBack()}
          >
            <Text style={styles.backButtonText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.courseTitle}>Course Not Found</Text>
        </View>
        <View style={[styles.loadingContainer, { backgroundColor: colors.background }]}>
          <Text style={{ color: colors.textSecondary }}>
            The requested course could not be found.
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.courseTitle}>{course.title}</Text>
        <Text style={styles.coursePlatform}>{course.platform}</Text>
      </View>
      
      <View style={styles.progressSection}>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View
              style={[
                styles.progressFill,
                { width: `${course.progress}%`, backgroundColor: colors.primary },
              ]}
            />
          </View>
          <Text style={styles.progressText}>{course.progress}%</Text>
        </View>
        
        <View style={styles.progressControls}>
          {[0, 25, 50, 75, 100].map((value) => (
            <TouchableOpacity
              key={value}
              style={styles.progressButton}
              onPress={() => updateProgress(value)}
            >
              <Text style={styles.progressButtonText}>{value}%</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>
      
      <View style={styles.tabsContainer}>
        <TouchableOpacity
          style={[styles.tab, activeTab === 'overview' && styles.activeTab]}
          onPress={() => setActiveTab('overview')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'overview' && styles.activeTabText,
            ]}
          >
            Overview
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'deadlines' && styles.activeTab]}
          onPress={() => setActiveTab('deadlines')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'deadlines' && styles.activeTabText,
            ]}
          >
            Deadlines
          </Text>
        </TouchableOpacity>
        
        <TouchableOpacity
          style={[styles.tab, activeTab === 'schedule' && styles.activeTab]}
          onPress={() => setActiveTab('schedule')}
        >
          <Text
            style={[
              styles.tabText,
              activeTab === 'schedule' && styles.activeTabText,
            ]}
          >
            Schedule
          </Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView
        style={styles.content}
        contentContainerStyle={styles.tabContent}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {activeTab === 'overview' && (
          <>
            <View
              style={[
                styles.statusBadge,
                {
                  backgroundColor:
                    course.status === 'active'
                      ? 'rgba(16, 185, 129, 0.1)'
                      : course.status === 'completed'
                        ? 'rgba(59, 130, 246, 0.1)'
                        : 'rgba(156, 163, 175, 0.1)',
                  borderWidth: 1,
                  borderColor:
                    course.status === 'active'
                      ? colors.secondary
                      : course.status === 'completed'
                        ? colors.primary
                        : colors.textSecondary,
                },
              ]}
            >
              <Text
                style={[
                  styles.statusText,
                  {
                    color:
                      course.status === 'active'
                        ? colors.secondary
                        : course.status === 'completed'
                          ? colors.primary
                          : colors.textSecondary,
                  },
                ]}
              >
                {course.status.charAt(0).toUpperCase() + course.status.slice(1)}
              </Text>
            </View>
            
            <Text style={styles.description}>{course.description}</Text>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Instructor:</Text>
              <Text style={styles.infoValue}>{course.instructor || 'N/A'}</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Start Date:</Text>
              <Text style={styles.infoValue}>{formatDate(course.startDate)}</Text>
            </View>
            
            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>End Date:</Text>
              <Text style={styles.infoValue}>
                {course.endDate ? formatDate(course.endDate) : 'Ongoing'}
              </Text>
            </View>
            
            {course.url && (
              <TouchableOpacity
                style={styles.linkButton}
                onPress={() => {
                  // In a real app, this would open the URL
                  Alert.alert('Open Course', `Would open: ${course.url}`);
                }}
              >
                <Text style={styles.linkButtonText}>Open Course</Text>
              </TouchableOpacity>
            )}
          </>
        )}
        
        {activeTab === 'deadlines' && (
          <>
            <Text style={styles.sectionTitle}>Deadlines</Text>
            
            {deadlines.length > 0 ? (
              <FlatList
                data={deadlines}
                renderItem={renderDeadlineItem}
                keyExtractor={(item) => item.id.toString()}
                scrollEnabled={false}
              />
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>
                  No deadlines found for this course.
                </Text>
              </View>
            )}
          </>
        )}
        
        {activeTab === 'schedule' && (
          <>
            <Text style={styles.sectionTitle}>Schedule</Text>
            
            {sessions.length > 0 ? (
              <FlatList
                data={sessions}
                renderItem={renderSessionItem}
                keyExtractor={(item) => item.id.toString()}
                scrollEnabled={false}
              />
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>
                  No scheduled sessions found for this course.
                </Text>
              </View>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
};

export default CourseDetailScreen;