import React, { useState, useEffect } from 'react';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Import screens
import AuthScreen from './screens/AuthScreen';
import DashboardScreen from './screens/DashboardScreen';
import CourseListScreen from './screens/CourseListScreen';
import CourseDetailScreen from './screens/CourseDetailScreen';
import DeadlinesScreen from './screens/DeadlinesScreen';
import NotesScreen from './screens/NotesScreen';
import SettingsScreen from './screens/SettingsScreen';
import SplashScreen from './screens/SplashScreen';

// Import components
import { ThemeProvider } from './components/ThemeProvider';

// Import services
import { authService } from './shared/services/auth.service';
import { storageService } from './shared/services/storage.service';
import { serviceInitializer } from './shared/services/service-initializer';

// Define root stack navigator parameter list
type RootStackParamList = {
  Splash: undefined;
  Auth: undefined;
  Dashboard: undefined;
  CourseList: undefined;
  CourseDetail: { courseId: number };
  Deadlines: undefined;
  Notes: undefined;
  Settings: undefined;
};

// Create stack navigator
const Stack = createStackNavigator<RootStackParamList>();

// Initialize services
serviceInitializer.initialize();

const App = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  useEffect(() => {
    // Check if user is authenticated
    const checkAuth = async () => {
      try {
        await authService.initialize();
        setIsAuthenticated(authService.isAuthenticated());
      } catch (error) {
        console.error('Authentication error:', error);
      } finally {
        setIsLoading(false);
      }
    };

    // Add auth state listener
    const authStateListener = (authState: any) => {
      setIsAuthenticated(authState.isAuthenticated);
    };

    authService.addListener(authStateListener);
    checkAuth();

    // Clean up listener on unmount
    return () => {
      authService.removeListener(authStateListener);
    };
  }, []);

  if (isLoading) {
    return <SplashScreen />;
  }

  return (
    <SafeAreaProvider>
      <ThemeProvider>
        <NavigationContainer>
          <Stack.Navigator screenOptions={{ headerShown: false }}>
            {isAuthenticated ? (
              // Authenticated user routes
              <>
                <Stack.Screen name="Dashboard" component={DashboardScreen} />
                <Stack.Screen name="CourseList" component={CourseListScreen} />
                <Stack.Screen name="CourseDetail" component={CourseDetailScreen} />
                <Stack.Screen name="Deadlines" component={DeadlinesScreen} />
                <Stack.Screen name="Notes" component={NotesScreen} />
                <Stack.Screen name="Settings" component={SettingsScreen} />
              </>
            ) : (
              // Non-authenticated user routes
              <Stack.Screen name="Auth" component={AuthScreen} />
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </ThemeProvider>
    </SafeAreaProvider>
  );
};

export default App;