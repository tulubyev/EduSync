/**
 * API Service
 * Handles API communication for the mobile app
 */
import { Platform } from 'react-native';

/**
 * API service class for handling API requests in mobile apps
 */
export class ApiService {
  private baseUrl: string;
  private authToken: string | null = null;

  constructor() {
    // In a development environment, we might use different URLs based on platform
    if (Platform.OS === 'ios' && __DEV__) {
      // iOS simulator can use localhost
      this.baseUrl = 'http://localhost:3000';
    } else if (Platform.OS === 'android' && __DEV__) {
      // Android emulator needs special IP
      this.baseUrl = 'http://10.0.2.2:3000';
    } else {
      // Production environment
      this.baseUrl = 'https://api.eduaggregator.com';
    }
  }

  /**
   * Set auth token for authenticated requests
   */
  setAuthToken(token: string): void {
    this.authToken = token;
  }

  /**
   * Clear auth token
   */
  clearAuthToken(): void {
    this.authToken = null;
  }

  /**
   * Get headers for API requests
   */
  private getHeaders(): Record<string, string> {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'Accept': 'application/json',
    };

    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }

    return headers;
  }

  /**
   * Make a GET request to the API
   */
  async get<T = any>(endpoint: string, params?: Record<string, any>): Promise<T> {
    let url = `${this.baseUrl}${endpoint}`;
    
    // Add query parameters if provided
    if (params) {
      const queryParams = Object.entries(params)
        .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`)
        .join('&');
      
      url += (url.includes('?') ? '&' : '?') + queryParams;
    }

    const response = await fetch(url, {
      method: 'GET',
      headers: this.getHeaders(),
    });

    return this.handleResponse<T>(response);
  }

  /**
   * Make a POST request to the API
   */
  async post<T = any>(endpoint: string, body?: any): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: 'POST',
      headers: this.getHeaders(),
      body: body ? JSON.stringify(body) : undefined,
    });

    return this.handleResponse<T>(response);
  }

  /**
   * Make a PUT request to the API
   */
  async put<T = any>(endpoint: string, body?: any): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: body ? JSON.stringify(body) : undefined,
    });

    return this.handleResponse<T>(response);
  }

  /**
   * Make a PATCH request to the API
   */
  async patch<T = any>(endpoint: string, body?: any): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: body ? JSON.stringify(body) : undefined,
    });

    return this.handleResponse<T>(response);
  }

  /**
   * Make a DELETE request to the API
   */
  async delete<T = any>(endpoint: string): Promise<T> {
    const response = await fetch(`${this.baseUrl}${endpoint}`, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });

    return this.handleResponse<T>(response);
  }

  /**
   * Handle API response
   */
  private async handleResponse<T>(response: Response): Promise<T> {
    // Special case: for 204 No Content, just return empty object
    if (response.status === 204) {
      return {} as T;
    }

    let data: any;
    
    try {
      // Try to parse response as JSON
      const contentType = response.headers.get('content-type');
      if (contentType && contentType.includes('application/json')) {
        data = await response.json();
      } else {
        data = await response.text();
      }
    } catch (error) {
      console.error('Error parsing response:', error);
      throw new Error('Failed to parse response from server');
    }

    // Handle non-2xx responses
    if (!response.ok) {
      const errorMessage = typeof data === 'object' && data.message
        ? data.message
        : typeof data === 'string'
          ? data
          : 'Unknown error occurred';
      
      const error = new Error(errorMessage) as Error & { status?: number, data?: any };
      error.status = response.status;
      error.data = data;
      throw error;
    }

    return data as T;
  }
}

// Export singleton instance
export const apiService = new ApiService();