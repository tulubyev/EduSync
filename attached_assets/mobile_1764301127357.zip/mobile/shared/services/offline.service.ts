/**
 * Offline Service
 * Handles offline functionality for the mobile app
 */
import { Platform, NetInfo } from 'react-native';
import { StorageService } from './storage.service';

// Get platform-specific configuration
const platformConfig = Platform.OS === 'ios' 
  ? require('../../ios/AppConfig').default
  : require('../../android/AppConfig').default;

const { FEATURE_FLAGS } = platformConfig;

/**
 * Sync queue item interface
 */
interface SyncQueueItem {
  id: string;
  url: string;
  method: string;
  body?: any;
  headers?: Record<string, string>;
  createdAt: number;
  retryCount: number;
  maxRetries: number;
}

/**
 * Offline cache item interface
 */
interface CacheItem {
  url: string;
  data: any;
  expiresAt: number;
}

/**
 * Offline service configuration
 */
interface OfflineServiceConfig {
  enabled: boolean;
  maxQueueSize: number;
  maxQueueAge: number; // in ms
  maxRetries: number;
  cacheExpiration: number; // in ms
  syncInterval: number; // in ms
}

/**
 * Default offline service configuration
 */
const DEFAULT_CONFIG: OfflineServiceConfig = {
  enabled: FEATURE_FLAGS.ENABLE_OFFLINE_MODE,
  maxQueueSize: 1000,
  maxQueueAge: 7 * 24 * 60 * 60 * 1000, // 7 days
  maxRetries: 5,
  cacheExpiration: 24 * 60 * 60 * 1000, // 24 hours
  syncInterval: 15 * 60 * 1000 // 15 minutes
};

/**
 * Offline service class for handling offline functionality in mobile apps
 */
export class OfflineService {
  private storageService: StorageService;
  private config: OfflineServiceConfig;
  private isOnline: boolean = true;
  private syncQueue: SyncQueueItem[] = [];
  private cache: Map<string, CacheItem> = new Map();
  private syncIntervalId: any = null;
  private QUEUE_STORAGE_KEY = 'offline_sync_queue';
  private CACHE_STORAGE_KEY = 'offline_cache';

  constructor(storageService: StorageService, config: Partial<OfflineServiceConfig> = {}) {
    this.storageService = storageService;
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Initialize offline service
   */
  async initialize(): Promise<void> {
    if (!this.config.enabled) {
      return;
    }

    // Load queue and cache from storage
    await this.loadQueue();
    await this.loadCache();

    // Set up network listeners
    this.setupNetworkListeners();
    
    // Start sync interval
    this.startSyncInterval();
  }

  /**
   * Set up network listeners
   */
  private setupNetworkListeners(): void {
    // In a real app, we would use NetInfo or similar
    // NetInfo.addEventListener(state => {
    //   const wasOnline = this.isOnline;
    //   this.isOnline = state.isConnected && state.isInternetReachable;
    //   
    //   if (!wasOnline && this.isOnline) {
    //     // We're back online, try to sync
    //     this.processQueue();
    //   }
    // });
    
    // For now, assume we're online
    this.isOnline = true;
  }

  /**
   * Start sync interval
   */
  private startSyncInterval(): void {
    if (this.syncIntervalId) {
      clearInterval(this.syncIntervalId);
    }
    
    this.syncIntervalId = setInterval(() => {
      if (this.isOnline && this.syncQueue.length > 0) {
        this.processQueue();
      }
    }, this.config.syncInterval);
  }

  /**
   * Stop sync interval
   */
  private stopSyncInterval(): void {
    if (this.syncIntervalId) {
      clearInterval(this.syncIntervalId);
      this.syncIntervalId = null;
    }
  }

  /**
   * Load queue from storage
   */
  private async loadQueue(): Promise<void> {
    try {
      const queueJson = await this.storageService.getItem(this.QUEUE_STORAGE_KEY);
      if (queueJson) {
        this.syncQueue = JSON.parse(queueJson);
        
        // Filter out expired items
        const now = Date.now();
        this.syncQueue = this.syncQueue.filter(item => {
          return now - item.createdAt < this.config.maxQueueAge;
        });
        
        // Save filtered queue
        await this.saveQueue();
      }
    } catch (error) {
      console.error('Error loading offline sync queue:', error);
      this.syncQueue = [];
    }
  }

  /**
   * Save queue to storage
   */
  private async saveQueue(): Promise<void> {
    try {
      await this.storageService.setItem(
        this.QUEUE_STORAGE_KEY,
        JSON.stringify(this.syncQueue)
      );
    } catch (error) {
      console.error('Error saving offline sync queue:', error);
    }
  }

  /**
   * Load cache from storage
   */
  private async loadCache(): Promise<void> {
    try {
      const cacheJson = await this.storageService.getItem(this.CACHE_STORAGE_KEY);
      if (cacheJson) {
        const cacheData = JSON.parse(cacheJson);
        
        // Filter out expired items
        const now = Date.now();
        Object.entries(cacheData).forEach(([key, value]: [string, CacheItem]) => {
          if (now < value.expiresAt) {
            this.cache.set(key, value);
          }
        });
        
        // Save filtered cache
        await this.saveCache();
      }
    } catch (error) {
      console.error('Error loading offline cache:', error);
      this.cache.clear();
    }
  }

  /**
   * Save cache to storage
   */
  private async saveCache(): Promise<void> {
    try {
      const cacheData = {};
      this.cache.forEach((value, key) => {
        cacheData[key] = value;
      });
      
      await this.storageService.setItem(
        this.CACHE_STORAGE_KEY,
        JSON.stringify(cacheData)
      );
    } catch (error) {
      console.error('Error saving offline cache:', error);
    }
  }

  /**
   * Add request to sync queue
   */
  async queueRequest(
    url: string,
    method: string,
    body?: any,
    headers?: Record<string, string>
  ): Promise<string> {
    if (!this.config.enabled) {
      throw new Error('Offline mode is disabled');
    }
    
    // Check queue size limit
    if (this.syncQueue.length >= this.config.maxQueueSize) {
      throw new Error('Sync queue is full');
    }
    
    const id = `${method}_${url}_${Date.now()}`;
    const queueItem: SyncQueueItem = {
      id,
      url,
      method,
      body,
      headers,
      createdAt: Date.now(),
      retryCount: 0,
      maxRetries: this.config.maxRetries
    };
    
    this.syncQueue.push(queueItem);
    await this.saveQueue();
    
    // If we're online, try to process the queue immediately
    if (this.isOnline) {
      setTimeout(() => this.processQueue(), 0);
    }
    
    return id;
  }

  /**
   * Process sync queue
   */
  async processQueue(): Promise<void> {
    if (!this.isOnline || this.syncQueue.length === 0) {
      return;
    }
    
    const itemsToProcess = [...this.syncQueue];
    const failedItems: SyncQueueItem[] = [];
    
    for (const item of itemsToProcess) {
      try {
        await this.executeQueueItem(item);
        
        // Remove item from queue
        this.syncQueue = this.syncQueue.filter(i => i.id !== item.id);
      } catch (error) {
        console.error(`Error processing queue item ${item.id}:`, error);
        
        // Increment retry count and add back to failed items if retries left
        item.retryCount++;
        if (item.retryCount < item.maxRetries) {
          failedItems.push(item);
        }
      }
    }
    
    // Update queue with failed items
    this.syncQueue = this.syncQueue.filter(item => 
      !itemsToProcess.some(i => i.id === item.id)
    ).concat(failedItems);
    
    await this.saveQueue();
  }

  /**
   * Execute a queued request
   */
  private async executeQueueItem(item: SyncQueueItem): Promise<void> {
    const { url, method, body, headers } = item;
    
    const response = await fetch(url, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...headers
      },
      body: method !== 'GET' ? JSON.stringify(body) : undefined
    });
    
    if (!response.ok) {
      throw new Error(`Request failed with status ${response.status}`);
    }
  }

  /**
   * Get cached data
   */
  getCachedData(url: string): any | null {
    if (!this.config.enabled) {
      return null;
    }
    
    const cacheItem = this.cache.get(url);
    if (cacheItem && Date.now() < cacheItem.expiresAt) {
      return cacheItem.data;
    }
    
    return null;
  }

  /**
   * Cache data
   */
  async cacheData(url: string, data: any, expiration?: number): Promise<void> {
    if (!this.config.enabled) {
      return;
    }
    
    const expiresAt = Date.now() + (expiration || this.config.cacheExpiration);
    this.cache.set(url, { url, data, expiresAt });
    
    await this.saveCache();
  }

  /**
   * Clear cache for specific URL
   */
  async clearCache(url?: string): Promise<void> {
    if (url) {
      this.cache.delete(url);
    } else {
      this.cache.clear();
    }
    
    await this.saveCache();
  }

  /**
   * Clear sync queue
   */
  async clearQueue(): Promise<void> {
    this.syncQueue = [];
    await this.saveQueue();
  }

  /**
   * Get number of pending items in sync queue
   */
  getPendingItemsCount(): number {
    return this.syncQueue.length;
  }

  /**
   * Enable or disable offline mode
   */
  setOfflineModeEnabled(enabled: boolean): void {
    this.config.enabled = enabled;
    
    if (enabled) {
      this.startSyncInterval();
    } else {
      this.stopSyncInterval();
    }
  }

  /**
   * Check if offline mode is enabled
   */
  isOfflineModeEnabled(): boolean {
    return this.config.enabled;
  }

  /**
   * Check if device is online
   */
  isDeviceOnline(): boolean {
    return this.isOnline;
  }
}

// Initialize with StorageService later
export const offlineService = new OfflineService(null as any);