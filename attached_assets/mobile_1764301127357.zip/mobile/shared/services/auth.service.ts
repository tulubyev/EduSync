/**
 * Auth Service
 * Handles authentication for the mobile app
 */
import { storageService } from './storage.service';
import { apiService } from './api.service';

// Auth service events
type AuthEventListener = (state: { isAuthenticated: boolean; user: any }) => void;

/**
 * Auth service class for handling authentication in mobile apps
 */
export class AuthService {
  private static AUTH_TOKEN_KEY = 'auth_token';
  private static USER_DATA_KEY = 'user_data';
  private initialized = false;
  private authenticated = false;
  private user: any = null;
  private listeners: AuthEventListener[] = [];

  /**
   * Initialize auth service
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    try {
      // Check for existing auth token
      const token = await storageService.getItem(AuthService.AUTH_TOKEN_KEY);
      if (token) {
        // Set token in API service
        apiService.setAuthToken(token);
        
        // Try to get user data from storage
        const userData = await storageService.getObject(AuthService.USER_DATA_KEY);
        if (userData) {
          this.user = userData;
          this.authenticated = true;
        } else {
          // Fetch user data from API
          await this.fetchUserData();
        }
      }
    } catch (error) {
      console.error('Auth initialization error:', error);
      this.clearAuth();
    } finally {
      this.initialized = true;
    }
  }

  /**
   * Fetch user data from API
   */
  private async fetchUserData(): Promise<void> {
    try {
      const userData = await apiService.get('/api/user');
      if (userData) {
        this.user = userData;
        this.authenticated = true;
        await storageService.setObject(AuthService.USER_DATA_KEY, userData);
      } else {
        this.clearAuth();
      }
    } catch (error) {
      console.error('Error fetching user data:', error);
      this.clearAuth();
    }
  }

  /**
   * Clear authentication data
   */
  private async clearAuth(): Promise<void> {
    this.user = null;
    this.authenticated = false;
    apiService.clearAuthToken();
    await storageService.removeItem(AuthService.AUTH_TOKEN_KEY);
    await storageService.removeItem(AuthService.USER_DATA_KEY);
  }

  /**
   * Login with username and password
   */
  async login(username: string, password: string): Promise<boolean> {
    try {
      const response = await apiService.post('/api/login', { username, password });
      
      if (response && response.id) {
        // Store user data
        this.user = response;
        this.authenticated = true;
        await storageService.setObject(AuthService.USER_DATA_KEY, this.user);
        
        // Store session token if available
        if (response.token) {
          await storageService.setItem(AuthService.AUTH_TOKEN_KEY, response.token);
          apiService.setAuthToken(response.token);
        }
        
        // Notify listeners
        this.notifyListeners();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  }

  /**
   * Register a new user
   */
  async register(userData: {
    username: string;
    email: string;
    password: string;
    fullName?: string;
  }): Promise<boolean> {
    try {
      const response = await apiService.post('/api/register', userData);
      
      if (response && response.id) {
        // Store user data
        this.user = response;
        this.authenticated = true;
        await storageService.setObject(AuthService.USER_DATA_KEY, this.user);
        
        // Store session token if available
        if (response.token) {
          await storageService.setItem(AuthService.AUTH_TOKEN_KEY, response.token);
          apiService.setAuthToken(response.token);
        }
        
        // Notify listeners
        this.notifyListeners();
        return true;
      }
      return false;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  }

  /**
   * Logout current user
   */
  async logout(): Promise<void> {
    try {
      // Call logout API
      await apiService.post('/api/logout');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      // Clear auth data anyway
      await this.clearAuth();
      // Notify listeners
      this.notifyListeners();
    }
  }

  /**
   * Get current authenticated user
   */
  getUser(): any {
    return this.user;
  }

  /**
   * Check if user is authenticated
   */
  isAuthenticated(): boolean {
    return this.authenticated;
  }

  /**
   * Refresh user data from API
   */
  async refreshUserData(): Promise<void> {
    if (this.authenticated) {
      await this.fetchUserData();
      this.notifyListeners();
    }
  }

  /**
   * Add auth state listener
   */
  addListener(listener: AuthEventListener): void {
    this.listeners.push(listener);
  }

  /**
   * Remove auth state listener
   */
  removeListener(listener: AuthEventListener): void {
    this.listeners = this.listeners.filter(l => l !== listener);
  }

  /**
   * Notify all listeners of auth state changes
   */
  private notifyListeners(): void {
    const state = {
      isAuthenticated: this.authenticated,
      user: this.user
    };
    this.listeners.forEach(listener => listener(state));
  }
}

// Export singleton instance
export const authService = new AuthService();