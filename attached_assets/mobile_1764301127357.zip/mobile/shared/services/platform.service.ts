/**
 * Platform Integration Service
 * Handles integration with educational platforms for the mobile app
 */
import { Platform } from 'react-native';
import { AuthService } from './auth.service';
import { ApiService } from './api.service';
import { Course, Deadline, Platform as LearningPlatform, Session } from '../../../shared/schema';

// Get platform-specific configuration
const platformConfig = Platform.OS === 'ios' 
  ? require('../../ios/AppConfig').default
  : require('../../android/AppConfig').default;

/**
 * Platform connection credentials interface
 */
interface PlatformCredentials {
  username?: string;
  password?: string;
  apiKey?: string;
  accessToken?: string;
  refreshToken?: string;
  [key: string]: any;
}

/**
 * Sync result interface
 */
interface SyncResult<T> {
  success: boolean;
  data?: T[];
  error?: string;
  timestamp: number;
}

/**
 * Platform service class for handling integration with learning platforms in mobile apps
 */
export class PlatformService {
  private apiService: ApiService;
  private authService: AuthService;

  constructor(apiService: ApiService, authService: AuthService) {
    this.apiService = apiService;
    this.authService = authService;
  }

  /**
   * Get all available platforms
   */
  async getAvailablePlatforms(): Promise<LearningPlatform[]> {
    try {
      const response = await this.apiService.get<LearningPlatform[]>('/platforms');
      return response.data;
    } catch (error) {
      console.error('Error fetching available platforms:', error);
      throw error;
    }
  }

  /**
   * Get platforms by region
   */
  async getPlatformsByRegion(region: string): Promise<LearningPlatform[]> {
    try {
      const response = await this.apiService.get<LearningPlatform[]>('/platforms', {
        params: { region }
      });
      return response.data;
    } catch (error) {
      console.error(`Error fetching platforms for region ${region}:`, error);
      throw error;
    }
  }

  /**
   * Get user's connected platforms
   */
  async getUserPlatforms(): Promise<LearningPlatform[]> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.get<LearningPlatform[]>('/platforms', {
        requiresAuth: true
      });
      return response.data;
    } catch (error) {
      console.error('Error fetching user platforms:', error);
      throw error;
    }
  }

  /**
   * Connect to a platform
   */
  async connectPlatform(platformId: number, credentials: PlatformCredentials): Promise<boolean> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.patch<{ success: boolean }>(`/platforms/${platformId}/connect`, {
        credentials
      }, {
        requiresAuth: true
      });

      return response.data.success;
    } catch (error) {
      console.error(`Error connecting to platform ${platformId}:`, error);
      throw error;
    }
  }

  /**
   * Disconnect from a platform
   */
  async disconnectPlatform(platformId: number): Promise<boolean> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.patch<{ success: boolean }>(`/platforms/${platformId}/disconnect`, {}, {
        requiresAuth: true
      });

      return response.data.success;
    } catch (error) {
      console.error(`Error disconnecting from platform ${platformId}:`, error);
      throw error;
    }
  }

  /**
   * Sync courses from a platform
   */
  async syncCoursesFromPlatform(platformId: number): Promise<SyncResult<Course>> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.post<{ 
        success: boolean, 
        courses?: Course[],
        error?: string
      }>(`/platforms/${platformId}/sync`, {}, {
        requiresAuth: true
      });

      return {
        success: response.data.success,
        data: response.data.courses,
        error: response.data.error,
        timestamp: Date.now()
      };
    } catch (error) {
      console.error(`Error syncing courses from platform ${platformId}:`, error);
      return {
        success: false,
        error: error.message || 'Unknown error occurred',
        timestamp: Date.now()
      };
    }
  }

  /**
   * Sync deadlines for a course
   */
  async syncDeadlinesForCourse(courseId: number): Promise<SyncResult<Deadline>> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.post<{
        success: boolean,
        deadlines?: Deadline[],
        error?: string
      }>(`/courses/${courseId}/sync-deadlines`, {}, {
        requiresAuth: true
      });

      return {
        success: response.data.success,
        data: response.data.deadlines,
        error: response.data.error,
        timestamp: Date.now()
      };
    } catch (error) {
      console.error(`Error syncing deadlines for course ${courseId}:`, error);
      return {
        success: false,
        error: error.message || 'Unknown error occurred',
        timestamp: Date.now()
      };
    }
  }

  /**
   * Sync schedule for a course
   */
  async syncScheduleForCourse(courseId: number): Promise<SyncResult<Session>> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.post<{
        success: boolean,
        sessions?: Session[],
        error?: string
      }>(`/courses/${courseId}/sync-schedule`, {}, {
        requiresAuth: true
      });

      return {
        success: response.data.success,
        data: response.data.sessions,
        error: response.data.error,
        timestamp: Date.now()
      };
    } catch (error) {
      console.error(`Error syncing schedule for course ${courseId}:`, error);
      return {
        success: false,
        error: error.message || 'Unknown error occurred',
        timestamp: Date.now()
      };
    }
  }

  /**
   * Sync progress for a course back to platform
   */
  async syncProgressToPlatform(courseId: number, progress: number): Promise<boolean> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.patch<{ success: boolean }>(
        `/courses/${courseId}/progress`, 
        { progress }, 
        { requiresAuth: true }
      );

      return response.data.success;
    } catch (error) {
      console.error(`Error syncing progress for course ${courseId}:`, error);
      return false;
    }
  }

  /**
   * Get the last sync timestamp for a platform
   */
  async getLastSyncTimestamp(platformId: number): Promise<number | null> {
    try {
      if (!this.authService.isAuthenticated()) {
        throw new Error('User is not authenticated');
      }

      const response = await this.apiService.get<{ lastSyncedAt: string | null }>(
        `/platforms/${platformId}`, 
        { requiresAuth: true }
      );

      return response.data.lastSyncedAt ? new Date(response.data.lastSyncedAt).getTime() : null;
    } catch (error) {
      console.error(`Error getting last sync timestamp for platform ${platformId}:`, error);
      return null;
    }
  }
}

// Initialize with ApiService and AuthService later
export const platformService = new PlatformService(null as any, null as any);