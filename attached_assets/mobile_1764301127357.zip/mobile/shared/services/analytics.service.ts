/**
 * Analytics Service
 * Handles analytics tracking for the mobile app
 */
import { Platform } from 'react-native';
import { StorageService } from './storage.service';
import { OfflineService } from './offline.service';

// Get platform-specific configuration
const platformConfig = Platform.OS === 'ios' 
  ? require('../../ios/AppConfig').default
  : require('../../android/AppConfig').default;

const { FEATURE_FLAGS } = platformConfig;

/**
 * Analytics event interface
 */
interface AnalyticsEvent {
  eventName: string;
  properties: Record<string, any>;
  timestamp: number;
}

/**
 * User property interface
 */
interface UserProperty {
  key: string;
  value: any;
}

/**
 * Analytics service configuration
 */
interface AnalyticsConfig {
  enabled: boolean;
  trackNavigation: boolean;
  trackErrors: boolean;
  trackUserProperties: boolean;
  sampleRate: number;
  maxQueueSize: number;
  batchSize: number;
  flushInterval: number;
}

/**
 * Default analytics configuration
 */
const DEFAULT_CONFIG: AnalyticsConfig = {
  enabled: FEATURE_FLAGS.ENABLE_ANALYTICS,
  trackNavigation: true,
  trackErrors: true,
  trackUserProperties: true,
  sampleRate: 1.0, // 100% of events
  maxQueueSize: 1000,
  batchSize: 20,
  flushInterval: 30000 // 30 seconds
};

/**
 * Standard event names
 */
export enum AnalyticsEventName {
  APP_OPENED = 'app_opened',
  APP_BACKGROUNDED = 'app_backgrounded',
  APP_FOREGROUNDED = 'app_foregrounded',
  SCREEN_VIEW = 'screen_view',
  USER_LOGIN = 'user_login',
  USER_LOGOUT = 'user_logout',
  USER_REGISTER = 'user_register',
  COURSE_VIEW = 'course_view',
  COURSE_PROGRESS_UPDATE = 'course_progress_update',
  DEADLINE_VIEW = 'deadline_view',
  DEADLINE_COMPLETED = 'deadline_completed',
  NOTE_CREATED = 'note_created',
  NOTE_UPDATED = 'note_updated',
  PLATFORM_CONNECTED = 'platform_connected',
  PLATFORM_DISCONNECTED = 'platform_disconnected',
  PLATFORM_SYNCED = 'platform_synced',
  SEARCH_PERFORMED = 'search_performed',
  ERROR_OCCURRED = 'error_occurred',
  NOTIFICATION_RECEIVED = 'notification_received',
  NOTIFICATION_OPENED = 'notification_opened',
}

/**
 * Analytics service class for tracking events in mobile apps
 */
export class AnalyticsService {
  private storageService: StorageService;
  private offlineService: OfflineService;
  private config: AnalyticsConfig;
  private sessionId: string;
  private eventQueue: AnalyticsEvent[] = [];
  private userProperties: Record<string, any> = {};
  private currentScreen: string | null = null;
  private flushIntervalId: any = null;
  private isFlushing: boolean = false;
  private QUEUE_STORAGE_KEY = 'analytics_event_queue';
  private USER_PROPERTIES_KEY = 'analytics_user_properties';

  constructor(storageService: StorageService, offlineService: OfflineService, config: Partial<AnalyticsConfig> = {}) {
    this.storageService = storageService;
    this.offlineService = offlineService;
    this.config = { ...DEFAULT_CONFIG, ...config };
    this.sessionId = this.generateSessionId();
  }

  /**
   * Initialize analytics service
   */
  async initialize(): Promise<void> {
    if (!this.config.enabled) {
      return;
    }

    // Load queue and user properties from storage
    await this.loadQueue();
    await this.loadUserProperties();
    
    // Start flush interval
    this.startFlushInterval();
    
    // Track app opened event
    this.trackEvent(AnalyticsEventName.APP_OPENED, {
      session_id: this.sessionId,
      platform: Platform.OS,
      version: Platform.OS === 'ios' 
        ? platformConfig.APP_CONFIG.APP_VERSION
        : platformConfig.APP_CONFIG.APP_VERSION,
      os_version: Platform.Version,
    });
  }

  /**
   * Generate a unique session ID
   */
  private generateSessionId(): string {
    return `${Platform.OS}_${Date.now()}_${Math.random().toString(36).substring(2, 15)}`;
  }

  /**
   * Load event queue from storage
   */
  private async loadQueue(): Promise<void> {
    try {
      const queueJson = await this.storageService.getItem(this.QUEUE_STORAGE_KEY);
      if (queueJson) {
        this.eventQueue = JSON.parse(queueJson);
        
        // Check max queue size
        if (this.eventQueue.length > this.config.maxQueueSize) {
          this.eventQueue = this.eventQueue.slice(-this.config.maxQueueSize);
        }
      }
    } catch (error) {
      console.error('Error loading analytics event queue:', error);
      this.eventQueue = [];
    }
  }

  /**
   * Save event queue to storage
   */
  private async saveQueue(): Promise<void> {
    try {
      await this.storageService.setItem(
        this.QUEUE_STORAGE_KEY,
        JSON.stringify(this.eventQueue)
      );
    } catch (error) {
      console.error('Error saving analytics event queue:', error);
    }
  }

  /**
   * Load user properties from storage
   */
  private async loadUserProperties(): Promise<void> {
    try {
      const propsJson = await this.storageService.getItem(this.USER_PROPERTIES_KEY);
      if (propsJson) {
        this.userProperties = JSON.parse(propsJson);
      }
    } catch (error) {
      console.error('Error loading analytics user properties:', error);
      this.userProperties = {};
    }
  }

  /**
   * Save user properties to storage
   */
  private async saveUserProperties(): Promise<void> {
    try {
      await this.storageService.setItem(
        this.USER_PROPERTIES_KEY,
        JSON.stringify(this.userProperties)
      );
    } catch (error) {
      console.error('Error saving analytics user properties:', error);
    }
  }

  /**
   * Start flush interval
   */
  private startFlushInterval(): void {
    if (this.flushIntervalId) {
      clearInterval(this.flushIntervalId);
    }
    
    this.flushIntervalId = setInterval(() => {
      this.flushQueue();
    }, this.config.flushInterval);
  }

  /**
   * Stop flush interval
   */
  private stopFlushInterval(): void {
    if (this.flushIntervalId) {
      clearInterval(this.flushIntervalId);
      this.flushIntervalId = null;
    }
  }

  /**
   * Track an analytics event
   */
  trackEvent(eventName: string, properties: Record<string, any> = {}): void {
    if (!this.config.enabled) {
      return;
    }
    
    // Apply sampling rate
    if (Math.random() > this.config.sampleRate) {
      return;
    }
    
    // Create event object
    const event: AnalyticsEvent = {
      eventName,
      properties: {
        ...properties,
        session_id: this.sessionId,
        screen: this.currentScreen,
      },
      timestamp: Date.now()
    };
    
    // Add to queue
    this.eventQueue.push(event);
    
    // Check max queue size
    if (this.eventQueue.length > this.config.maxQueueSize) {
      this.eventQueue.shift();
    }
    
    // Save queue
    this.saveQueue();
    
    // If queue is getting large, flush it
    if (this.eventQueue.length >= this.config.batchSize && !this.isFlushing) {
      setTimeout(() => this.flushQueue(), 0);
    }
  }

  /**
   * Track screen view
   */
  trackScreenView(screenName: string, properties: Record<string, any> = {}): void {
    if (!this.config.trackNavigation) {
      return;
    }
    
    this.currentScreen = screenName;
    
    this.trackEvent(AnalyticsEventName.SCREEN_VIEW, {
      screen_name: screenName,
      ...properties
    });
  }

  /**
   * Track error
   */
  trackError(errorName: string, errorMessage: string, stack?: string): void {
    if (!this.config.trackErrors) {
      return;
    }
    
    this.trackEvent(AnalyticsEventName.ERROR_OCCURRED, {
      error_name: errorName,
      error_message: errorMessage,
      error_stack: stack,
      screen: this.currentScreen
    });
  }

  /**
   * Set user ID
   */
  setUserId(userId: string | number): void {
    if (!this.config.trackUserProperties) {
      return;
    }
    
    this.setUserProperty('user_id', userId);
  }

  /**
   * Set user property
   */
  setUserProperty(key: string, value: any): void {
    if (!this.config.trackUserProperties) {
      return;
    }
    
    this.userProperties[key] = value;
    this.saveUserProperties();
  }

  /**
   * Set multiple user properties
   */
  setUserProperties(properties: Record<string, any>): void {
    if (!this.config.trackUserProperties) {
      return;
    }
    
    Object.entries(properties).forEach(([key, value]) => {
      this.userProperties[key] = value;
    });
    
    this.saveUserProperties();
  }

  /**
   * Clear user property
   */
  clearUserProperty(key: string): void {
    delete this.userProperties[key];
    this.saveUserProperties();
  }

  /**
   * Clear all user properties
   */
  clearAllUserProperties(): void {
    this.userProperties = {};
    this.saveUserProperties();
  }

  /**
   * Flush event queue
   */
  async flushQueue(): Promise<boolean> {
    if (!this.config.enabled || this.eventQueue.length === 0 || this.isFlushing) {
      return false;
    }
    
    this.isFlushing = true;
    try {
      // Take batch of events
      const batch = this.eventQueue.slice(0, this.config.batchSize);
      
      // Skip if no events to send
      if (batch.length === 0) {
        this.isFlushing = false;
        return true;
      }
      
      // Prepare payload
      const payload = {
        events: batch,
        user_properties: this.userProperties,
        client: {
          platform: Platform.OS,
          app_version: Platform.OS === 'ios' 
            ? platformConfig.APP_CONFIG.APP_VERSION
            : platformConfig.APP_CONFIG.APP_VERSION,
          os_version: Platform.Version,
          device_model: Platform.OS,
          locale: 'en-US', // In a real app, we'd get the actual locale
        },
        timestamp: Date.now()
      };
      
      // Try to send events
      if (this.offlineService.isDeviceOnline()) {
        const response = await fetch(`${platformConfig.API_CONFIG.BASE_URL}/api/analytics/events`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
          },
          body: JSON.stringify(payload)
        });
        
        if (!response.ok) {
          throw new Error(`Failed to send analytics events: ${response.status}`);
        }
        
        // Remove sent events from queue
        this.eventQueue = this.eventQueue.slice(batch.length);
        await this.saveQueue();
        
        return true;
      } else {
        // Device is offline, queue the analytics request
        if (this.offlineService.isOfflineModeEnabled()) {
          await this.offlineService.queueRequest(
            `${platformConfig.API_CONFIG.BASE_URL}/api/analytics/events`,
            'POST',
            payload,
            {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
            }
          );
          
          // Remove sent events from queue
          this.eventQueue = this.eventQueue.slice(batch.length);
          await this.saveQueue();
          
          return true;
        }
      }
      
      return false;
    } catch (error) {
      console.error('Error flushing analytics queue:', error);
      return false;
    } finally {
      this.isFlushing = false;
    }
  }

  /**
   * Enable or disable analytics
   */
  setEnabled(enabled: boolean): void {
    this.config.enabled = enabled;
    
    if (enabled) {
      this.startFlushInterval();
    } else {
      this.stopFlushInterval();
    }
  }

  /**
   * Check if analytics is enabled
   */
  isEnabled(): boolean {
    return this.config.enabled;
  }

  /**
   * Get current event queue size
   */
  getQueueSize(): number {
    return this.eventQueue.length;
  }

  /**
   * Get current session ID
   */
  getSessionId(): string {
    return this.sessionId;
  }

  /**
   * Start a new session
   */
  startNewSession(): void {
    this.sessionId = this.generateSessionId();
    
    this.trackEvent(AnalyticsEventName.APP_FOREGROUNDED, {
      session_id: this.sessionId,
    });
  }

  /**
   * End current session
   */
  endSession(): void {
    this.trackEvent(AnalyticsEventName.APP_BACKGROUNDED, {
      session_id: this.sessionId,
      duration_ms: Date.now() - parseInt(this.sessionId.split('_')[1]),
    });
    
    // Flush queue immediately
    this.flushQueue();
  }
}

// Initialize with StorageService and OfflineService later
export const analyticsService = new AnalyticsService(null as any, null as any);