/**
 * Storage Service
 * Handles secure local storage for the mobile app
 */
import { Platform } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

// For a production app, we would use more secure storage options:
// - iOS: expo-secure-store or react-native-keychain
// - Android: react-native-encrypted-storage or other secure storage solution

/**
 * Storage service class for handling secure data storage in mobile apps
 */
export class StorageService {
  private prefix: string;
  private secureMode: boolean;

  constructor(prefix = 'eduaggregator:', secureMode = true) {
    this.prefix = prefix;
    this.secureMode = secureMode;
  }

  /**
   * Generate full key with prefix
   */
  private getFullKey(key: string): string {
    return `${this.prefix}${key}`;
  }

  /**
   * Get item from storage
   */
  async getItem(key: string): Promise<string | null> {
    const fullKey = this.getFullKey(key);
    
    if (this.secureMode) {
      // In a real app, we would use the appropriate secure storage
      // based on the platform
      if (Platform.OS === 'ios') {
        // Secure storage for iOS would be here
        // return await SecureStore.getItemAsync(fullKey);
      } else {
        // Secure storage for Android would be here
        // return await EncryptedStorage.getItem(fullKey);
      }
      
      // For now, use AsyncStorage as a fallback
      return await AsyncStorage.getItem(fullKey);
    } else {
      return await AsyncStorage.getItem(fullKey);
    }
  }

  /**
   * Set item in storage
   */
  async setItem(key: string, value: string): Promise<void> {
    const fullKey = this.getFullKey(key);
    
    if (this.secureMode) {
      // In a real app, we would use the appropriate secure storage
      // based on the platform
      if (Platform.OS === 'ios') {
        // Secure storage for iOS would be here
        // await SecureStore.setItemAsync(fullKey, value);
      } else {
        // Secure storage for Android would be here
        // await EncryptedStorage.setItem(fullKey, value);
      }
      
      // For now, use AsyncStorage as a fallback
      await AsyncStorage.setItem(fullKey, value);
    } else {
      await AsyncStorage.setItem(fullKey, value);
    }
  }

  /**
   * Remove item from storage
   */
  async removeItem(key: string): Promise<void> {
    const fullKey = this.getFullKey(key);
    
    if (this.secureMode) {
      // In a real app, we would use the appropriate secure storage
      // based on the platform
      if (Platform.OS === 'ios') {
        // Secure storage for iOS would be here
        // await SecureStore.deleteItemAsync(fullKey);
      } else {
        // Secure storage for Android would be here
        // await EncryptedStorage.removeItem(fullKey);
      }
      
      // For now, use AsyncStorage as a fallback
      await AsyncStorage.removeItem(fullKey);
    } else {
      await AsyncStorage.removeItem(fullKey);
    }
  }

  /**
   * Clear all storage (only items with prefix)
   */
  async clear(): Promise<void> {
    const allKeys = await AsyncStorage.getAllKeys();
    const keysToRemove = allKeys.filter(key => key.startsWith(this.prefix));
    
    if (keysToRemove.length > 0) {
      await AsyncStorage.multiRemove(keysToRemove);
    }
    
    // In a real app, we would also clear the secure storage
    // based on the platform
    if (this.secureMode) {
      // Platform specific implementation would be here
    }
  }

  /**
   * Store object data (serialized as JSON)
   */
  async setObject(key: string, value: any): Promise<void> {
    const jsonValue = JSON.stringify(value);
    await this.setItem(key, jsonValue);
  }

  /**
   * Get object data (parsed from JSON)
   */
  async getObject<T>(key: string): Promise<T | null> {
    const jsonValue = await this.getItem(key);
    
    if (jsonValue === null) {
      return null;
    }
    
    try {
      return JSON.parse(jsonValue) as T;
    } catch (error) {
      console.error(`Error parsing JSON for key ${key}:`, error);
      return null;
    }
  }
}

// Export singleton instance
export const storageService = new StorageService();