/**
 * Notification Service
 * Handles push notifications for the mobile app
 */
import { Platform } from 'react-native';
import { StorageService } from './storage.service';

// Get platform-specific configuration
const platformConfig = Platform.OS === 'ios' 
  ? require('../../ios/AppConfig').default
  : require('../../android/AppConfig').default;

const { NOTIFICATION_CONFIG } = platformConfig;

/**
 * Notification types enum
 */
export enum NotificationType {
  DEADLINE_REMINDER = 'deadline_reminder',
  COURSE_PROGRESS = 'course_progress',
  SESSION_UPCOMING = 'session_upcoming',
  PLATFORM_SYNC = 'platform_sync',
  ACCOUNT = 'account'
}

/**
 * Notification preferences interface
 */
export interface NotificationPreferences {
  enabled: boolean;
  deadlineReminders: boolean;
  courseUpdates: boolean;
  sessionReminders: boolean;
  platformSyncUpdates: boolean;
  accountNotifications: boolean;
  sound: boolean;
  vibration: boolean;
  scheduleTime?: {
    start: string; // HH:MM format
    end: string; // HH:MM format
  };
}

/**
 * Default notification preferences
 */
const DEFAULT_NOTIFICATION_PREFERENCES: NotificationPreferences = {
  enabled: true,
  deadlineReminders: true,
  courseUpdates: true,
  sessionReminders: true,
  platformSyncUpdates: true,
  accountNotifications: true,
  sound: true,
  vibration: true
};

/**
 * Notification registration data
 */
interface DeviceRegistration {
  userId: number;
  deviceToken: string;
  platform: 'ios' | 'android';
  appVersion: string;
  deviceModel: string;
  osVersion: string;
}

/**
 * Notification service class for handling push notifications in mobile apps
 */
export class NotificationService {
  private storageService: StorageService;
  private deviceToken: string | null = null;
  private isPermissionGranted: boolean = false;
  private preferences: NotificationPreferences;
  private PREFERENCES_KEY = 'notification_preferences';
  private authTokenProvider: () => Promise<string>;

  constructor(storageService: StorageService, authTokenProvider?: () => Promise<string>) {
    this.storageService = storageService;
    this.preferences = DEFAULT_NOTIFICATION_PREFERENCES;
    
    // Set auth token provider or use a default empty one
    this.authTokenProvider = authTokenProvider || (async () => '');
  }

  /**
   * Initialize notification service
   */
  async initialize(): Promise<void> {
    // Load preferences from storage
    await this.loadPreferences();
    
    // Check if permissions are granted
    await this.checkPermissions();
    
    // Setup notification listeners
    this.setupNotificationListeners();
  }

  /**
   * Request permission to send notifications
   */
  async requestPermissions(): Promise<boolean> {
    try {
      // In a real app, this would be platform-specific code
      // For iOS:
      if (Platform.OS === 'ios') {
        // Using react-native-notifications or similar
        // const authStatus = await request('alert', 'sound', 'badge');
        // this.isPermissionGranted = authStatus === 'granted';
        
        // For now, we'll simulate a successful permission request
        this.isPermissionGranted = true;
      } else {
        // For Android, permissions are typically granted by default
        // but we would still handle notification channels
        // const channelId = await notifee.createChannel(NOTIFICATION_CONFIG);
        this.isPermissionGranted = true;
      }
      
      return this.isPermissionGranted;
    } catch (error) {
      console.error('Error requesting notification permissions:', error);
      this.isPermissionGranted = false;
      return false;
    }
  }

  /**
   * Check if notification permissions are granted
   */
  async checkPermissions(): Promise<boolean> {
    try {
      // In a real app, this would be platform-specific code
      // For iOS:
      if (Platform.OS === 'ios') {
        // const authStatus = await check('alert', 'sound', 'badge');
        // this.isPermissionGranted = authStatus === 'granted';
        
        // For now, simulate permissions check
        this.isPermissionGranted = true;
      } else {
        // For Android, permissions are typically granted by default
        this.isPermissionGranted = true;
      }
      
      return this.isPermissionGranted;
    } catch (error) {
      console.error('Error checking notification permissions:', error);
      return false;
    }
  }

  /**
   * Setup notification listeners
   */
  private setupNotificationListeners(): void {
    // In a real app, this would set up listeners for:
    // 1. Foreground notifications
    // 2. Background notifications
    // 3. Notification taps
    
    // Example for iOS:
    if (Platform.OS === 'ios') {
      // Using react-native-notifications or similar
      // notifications.ios.registerRemoteNotifications();
      // notifications.ios.events().registerNotificationReceivedForeground(...);
      // notifications.ios.events().registerNotificationOpened(...);
    } else {
      // For Android using libraries like react-native-firebase or notifee
      // messaging().onMessage(async remoteMessage => {...});
      // messaging().setBackgroundMessageHandler(async remoteMessage => {...});
      // notifee.onForegroundEvent(({ type, detail }) => {...});
      // notifee.onBackgroundEvent(async ({ type, detail }) => {...});
    }
  }

  /**
   * Register device for push notifications
   */
  async registerDevice(userId: number): Promise<boolean> {
    try {
      if (!this.isPermissionGranted) {
        const granted = await this.requestPermissions();
        if (!granted) {
          return false;
        }
      }
      
      if (!this.deviceToken) {
        // In a real app, we would get the token from the push notification service
        // For iOS: await messaging().getAPNSToken();
        // For Android: await messaging().getToken();
        
        // For now, simulate a token
        this.deviceToken = `sim_${Platform.OS}_${Date.now()}`;
      }
      
      // Get more detailed device information
      const deviceInfo = {
        platform: Platform.OS,
        model: Platform.OS === 'ios' 
          ? 'iPhone' // In a real app, we would use device-info library to get detailed model
          : 'Android',
        osVersion: Platform.Version.toString(),
        appVersion: platformConfig.APP_CONFIG.APP_VERSION,
        // Add additional device metrics if available
        screenSize: {
          width: globalThis.window ? globalThis.window.innerWidth || 0 : 0,
          height: globalThis.window ? globalThis.window.innerHeight || 0 : 0,
        },
        deviceLocale: 'en-US',  // In a real app, we would get this from the device
        timezone: Intl.DateTimeFormat().resolvedOptions().timeZone
      };
      
      // Register with the server
      const response = await fetch(`${platformConfig.API_CONFIG.BASE_URL}/api/notifications/register-mobile`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${await this.authTokenProvider()}`
        },
        body: JSON.stringify({
          token: this.deviceToken,  // Match the expected parameter name on the server
          deviceInfo
        })
      });
      
      if (!response.ok) {
        throw new Error('Device registration failed');
      }
      
      return true;
    } catch (error) {
      console.error('Error registering device for push notifications:', error);
      return false;
    }
  }

  /**
   * Unregister device from push notifications
   */
  async unregisterDevice(userId: number): Promise<boolean> {
    try {
      if (!this.deviceToken) {
        return true; // Already unregistered
      }
      
      // Unregister with the server
      const response = await fetch(`${platformConfig.API_CONFIG.BASE_URL}/api/notifications/unregister-mobile`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${await this.authTokenProvider()}`
        },
        body: JSON.stringify({
          token: this.deviceToken, // Match the expected parameter name on the server
        })
      });
      
      if (!response.ok) {
        throw new Error('Device unregistration failed');
      }
      
      // Clear device token
      this.deviceToken = null;
      
      return true;
    } catch (error) {
      console.error('Error unregistering device from push notifications:', error);
      return false;
    }
  }

  /**
   * Update notification preferences
   */
  async updatePreferences(preferences: Partial<NotificationPreferences>): Promise<void> {
    try {
      // Update local preferences
      this.preferences = { ...this.preferences, ...preferences };
      
      // Save to storage
      await this.storageService.setObject(this.PREFERENCES_KEY, this.preferences);
      
      // Update on server
      await fetch(`${platformConfig.API_CONFIG.BASE_URL}/api/notifications/preferences`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Authorization': `Bearer ${await this.authTokenProvider()}`
        },
        body: JSON.stringify(this.preferences)
      });
      
      // If notifications were disabled, handle accordingly
      if (preferences.enabled === false) {
        this.handleNotificationsDisabled();
      }
    } catch (error) {
      console.error('Error updating notification preferences:', error);
    }
  }

  /**
   * Load notification preferences from storage
   */
  private async loadPreferences(): Promise<void> {
    try {
      const storedPreferences = await this.storageService.getObject<NotificationPreferences>(
        this.PREFERENCES_KEY
      );
      
      if (storedPreferences) {
        this.preferences = { ...DEFAULT_NOTIFICATION_PREFERENCES, ...storedPreferences };
      }
    } catch (error) {
      console.error('Error loading notification preferences:', error);
      this.preferences = DEFAULT_NOTIFICATION_PREFERENCES;
    }
  }

  /**
   * Handle notifications being disabled
   */
  private handleNotificationsDisabled(): void {
    // Clear badges
    this.clearBadges();
    
    // Optionally cancel any scheduled notifications
    this.cancelAllScheduledNotifications();
  }

  /**
   * Clear notification badges
   */
  async clearBadges(): Promise<void> {
    if (Platform.OS === 'ios') {
      // Using react-native-notifications or similar
      // notifications.ios.setBadgeCount(0);
    }
  }

  /**
   * Set badge count
   */
  async setBadgeCount(count: number): Promise<void> {
    if (Platform.OS === 'ios') {
      // Using react-native-notifications or similar
      // notifications.ios.setBadgeCount(count);
    }
  }

  /**
   * Schedule a local notification
   */
  async scheduleNotification(
    title: string,
    body: string,
    timestamp: number,
    data: any = {},
    type: NotificationType = NotificationType.ACCOUNT
  ): Promise<string | null> {
    try {
      if (!this.isPermissionGranted || !this.preferences.enabled) {
        return null;
      }
      
      // Check notification preferences based on type
      if (!this.shouldShowNotification(type)) {
        return null;
      }
      
      // In a real app, this would use platform-specific code
      if (Platform.OS === 'ios') {
        // Using react-native-notifications or similar
        // return await notifications.ios.localNotification({
        //   title,
        //   body,
        //   userInfo: { ...data, type },
        //   fireDate: new Date(timestamp).toISOString(),
        //   sound: this.preferences.sound,
        // });
      } else {
        // For Android using libraries like react-native-firebase or notifee
        // return await notifee.createTriggerNotification({
        //   title,
        //   body,
        //   data: { ...data, type },
        //   android: {
        //     channelId: NOTIFICATION_CONFIG.NOTIFICATION_CHANNEL_ID,
        //     sound: this.preferences.sound,
        //     vibration: this.preferences.vibration,
        //   },
        // }, {
        //   type: TriggerType.TIMESTAMP,
        //   timestamp,
        // });
      }
      
      // For simulation
      console.log(`Scheduling notification: ${title} at ${new Date(timestamp).toISOString()}`);
      return `scheduled_${Date.now()}`;
    } catch (error) {
      console.error('Error scheduling notification:', error);
      return null;
    }
  }

  /**
   * Cancel a scheduled notification
   */
  async cancelScheduledNotification(id: string): Promise<void> {
    try {
      // In a real app, this would use platform-specific code
      if (Platform.OS === 'ios') {
        // Using react-native-notifications or similar
        // await notifications.ios.cancelLocalNotification(id);
      } else {
        // For Android
        // await notifee.cancelNotification(id);
      }
    } catch (error) {
      console.error('Error canceling scheduled notification:', error);
    }
  }

  /**
   * Cancel all scheduled notifications
   */
  async cancelAllScheduledNotifications(): Promise<void> {
    try {
      // In a real app, this would use platform-specific code
      if (Platform.OS === 'ios') {
        // Using react-native-notifications or similar
        // await notifications.ios.cancelAllLocalNotifications();
      } else {
        // For Android
        // await notifee.cancelAllNotifications();
      }
    } catch (error) {
      console.error('Error canceling all scheduled notifications:', error);
    }
  }

  /**
   * Check if a notification should be shown based on type and preferences
   */
  private shouldShowNotification(type: NotificationType): boolean {
    if (!this.preferences.enabled) {
      return false;
    }
    
    switch (type) {
      case NotificationType.DEADLINE_REMINDER:
        return this.preferences.deadlineReminders;
      case NotificationType.COURSE_PROGRESS:
        return this.preferences.courseUpdates;
      case NotificationType.SESSION_UPCOMING:
        return this.preferences.sessionReminders;
      case NotificationType.PLATFORM_SYNC:
        return this.preferences.platformSyncUpdates;
      case NotificationType.ACCOUNT:
        return this.preferences.accountNotifications;
      default:
        return true;
    }
  }

  /**
   * Check if notification is within schedule time
   */
  private isWithinScheduleTime(): boolean {
    const { scheduleTime } = this.preferences;
    
    if (!scheduleTime) {
      return true; // No schedule restrictions
    }
    
    const now = new Date();
    const currentTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    
    return currentTime >= scheduleTime.start && currentTime <= scheduleTime.end;
  }

  /**
   * Get notification preferences
   */
  getPreferences(): NotificationPreferences {
    return { ...this.preferences };
  }

  /**
   * Reset notification preferences to default
   */
  async resetPreferences(): Promise<void> {
    this.preferences = DEFAULT_NOTIFICATION_PREFERENCES;
    await this.storageService.setObject(this.PREFERENCES_KEY, this.preferences);
    
    // Update on server
    await fetch(`${platformConfig.API_CONFIG.BASE_URL}/api/notifications/preferences`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        'Authorization': `Bearer ${await this.authTokenProvider()}`
      },
      body: JSON.stringify(this.preferences)
    });
  }
}

// Initialize with StorageService later
export const notificationService = new NotificationService(null as any);