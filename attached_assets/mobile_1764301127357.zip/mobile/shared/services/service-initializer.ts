/**
 * Service Initializer
 * Handles initialization of all mobile app services
 */
import { apiService } from './api.service';
import { storageService } from './storage.service';

/**
 * Service initializer class for handling service initialization
 */
class ServiceInitializer {
  private initialized = false;

  /**
   * Initialize all services
   */
  async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    try {
      // Initialize app configuration
      await this.initAppConfig();
      
      // Initialize API service (first)
      this.initApiService();
      
      // Initialize other services
      // (Auth service is initialized when needed)
      
      this.initialized = true;
    } catch (error) {
      console.error('Service initialization error:', error);
      throw error;
    }
  }

  /**
   * Initialize app configuration from storage
   */
  private async initAppConfig(): Promise<void> {
    try {
      // Load app settings
      const settings = await storageService.getObject('app_settings');
      if (settings) {
        // Apply settings
        console.log('Loaded app settings:', settings);
      }
    } catch (error) {
      console.error('Error initializing app config:', error);
    }
  }

  /**
   * Initialize API service
   */
  private initApiService(): void {
    // Here we would configure the API service
    // based on environment, settings, etc.
    console.log('API service initialized');
  }
}

// Export singleton instance
export const serviceInitializer = new ServiceInitializer();