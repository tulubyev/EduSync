/**
 * iOS App Configuration
 * This file contains the configuration for the iOS app
 */

import { Platform } from 'react-native';

// API Configuration
export const API_CONFIG = {
  BASE_URL: 'https://api.eduaggregator.com',
  API_VERSION: 'v1',
  TIMEOUT: 30000, // 30 seconds
};

// Authentication Configuration
export const AUTH_CONFIG = {
  TOKEN_KEY: '@eduaggregator:auth_token',
  REFRESH_TOKEN_KEY: '@eduaggregator:refresh_token',
  USER_KEY: '@eduaggregator:user',
  SESSION_TIMEOUT: 30 * 24 * 60 * 60 * 1000, // 30 days
};

// App Configuration
export const APP_CONFIG = {
  APP_NAME: 'EduAggregator',
  APP_VERSION: '1.0.0',
  BUILD_NUMBER: '1',
  APP_BUNDLE_ID: 'com.eduaggregator.ios',
  MIN_IOS_VERSION: '12.0',
};

// Notification Configuration
export const NOTIFICATION_CONFIG = {
  NOTIFICATION_CHANNEL_ID: 'edu_aggregator_channel',
  NOTIFICATION_CHANNEL_NAME: 'EduAggregator Notifications',
  NOTIFICATION_CHANNEL_DESCRIPTION: 'Notifications from EduAggregator',
};

// Deep Linking Configuration
export const DEEP_LINK_CONFIG = {
  URL_SCHEME: 'eduaggregator://',
  UNIVERSAL_LINKS: ['https://eduaggregator.com/app'],
};

// Feature Flags
export const FEATURE_FLAGS = {
  ENABLE_BIOMETRIC_AUTHENTICATION: true,
  ENABLE_OFFLINE_MODE: true,
  ENABLE_PUSH_NOTIFICATIONS: true,
  ENABLE_ANALYTICS: true,
  ENABLE_CRASH_REPORTING: true,
};

// Screen Dimensions
export const SCREEN_DIMENSIONS = {
  isIphoneX: Platform.OS === 'ios' && (window.height >= 812 || window.width >= 812),
};

// Theme Configuration
export const THEME_CONFIG = {
  PRIMARY_COLOR: '#0069FE',
  SECONDARY_COLOR: '#34C759',
  TEXT_COLOR: '#333333',
  BACKGROUND_COLOR: '#FFFFFF',
  ERROR_COLOR: '#FF3B30',
  SUCCESS_COLOR: '#34C759',
  WARNING_COLOR: '#FF9500',
  INFO_COLOR: '#5AC8FA',
  BORDER_RADIUS: 8,
  FONT_FAMILY: {
    REGULAR: 'System',
    BOLD: 'System-Bold',
    LIGHT: 'System-Light',
    MEDIUM: 'System-Medium',
  },
};

// Export all configurations
export default {
  API_CONFIG,
  AUTH_CONFIG,
  APP_CONFIG,
  NOTIFICATION_CONFIG,
  DEEP_LINK_CONFIG,
  FEATURE_FLAGS,
  SCREEN_DIMENSIONS,
  THEME_CONFIG,
};