/**
 * Android App Configuration
 * This file contains the configuration for the Android app
 */

import { Platform } from 'react-native';

// API Configuration
export const API_CONFIG = {
  BASE_URL: 'https://api.eduaggregator.com',
  API_VERSION: 'v1',
  TIMEOUT: 30000, // 30 seconds
};

// Authentication Configuration
export const AUTH_CONFIG = {
  TOKEN_KEY: '@eduaggregator:auth_token',
  REFRESH_TOKEN_KEY: '@eduaggregator:refresh_token',
  USER_KEY: '@eduaggregator:user',
  SESSION_TIMEOUT: 30 * 24 * 60 * 60 * 1000, // 30 days
};

// App Configuration
export const APP_CONFIG = {
  APP_NAME: 'EduAggregator',
  APP_VERSION: '1.0.0',
  BUILD_NUMBER: '1',
  APP_PACKAGE_NAME: 'com.eduaggregator.android',
  MIN_ANDROID_VERSION: 21, // Android 5.0 (Lollipop)
  TARGET_ANDROID_VERSION: 33, // Android 13
};

// Notification Configuration
export const NOTIFICATION_CONFIG = {
  NOTIFICATION_CHANNEL_ID: 'edu_aggregator_channel',
  NOTIFICATION_CHANNEL_NAME: 'EduAggregator Notifications',
  NOTIFICATION_CHANNEL_DESCRIPTION: 'Notifications from EduAggregator',
  NOTIFICATION_ICON: 'ic_notification',
  NOTIFICATION_COLOR: '#0069FE',
};

// Deep Linking Configuration
export const DEEP_LINK_CONFIG = {
  URL_SCHEME: 'eduaggregator://',
  APP_LINKS: [
    'https://eduaggregator.com/app',
    'https://www.eduaggregator.com/app',
  ],
};

// Feature Flags
export const FEATURE_FLAGS = {
  ENABLE_BIOMETRIC_AUTHENTICATION: true,
  ENABLE_OFFLINE_MODE: true,
  ENABLE_PUSH_NOTIFICATIONS: true,
  ENABLE_ANALYTICS: true,
  ENABLE_CRASH_REPORTING: true,
  ENABLE_MATERIAL_YOU: true, // Android 12+ feature
};

// Device Utilities
export const DEVICE_UTILS = {
  hasNotch: Platform.OS === 'android' && Platform.Version >= 28,
  isAndroid12OrHigher: Platform.OS === 'android' && Platform.Version >= 31,
};

// Theme Configuration
export const THEME_CONFIG = {
  PRIMARY_COLOR: '#0069FE',
  SECONDARY_COLOR: '#34C759',
  TEXT_COLOR: '#333333',
  BACKGROUND_COLOR: '#FFFFFF',
  ERROR_COLOR: '#F44336',
  SUCCESS_COLOR: '#4CAF50',
  WARNING_COLOR: '#FF9800',
  INFO_COLOR: '#2196F3',
  BORDER_RADIUS: 8,
  FONT_FAMILY: {
    REGULAR: 'Roboto-Regular',
    BOLD: 'Roboto-Bold',
    LIGHT: 'Roboto-Light',
    MEDIUM: 'Roboto-Medium',
  },
};

// Export all configurations
export default {
  API_CONFIG,
  AUTH_CONFIG,
  APP_CONFIG,
  NOTIFICATION_CONFIG,
  DEEP_LINK_CONFIG,
  FEATURE_FLAGS,
  DEVICE_UTILS,
  THEME_CONFIG,
};