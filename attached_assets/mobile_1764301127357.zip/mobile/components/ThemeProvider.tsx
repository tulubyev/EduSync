/**
 * Theme Provider Component
 * Provides theming capabilities for the mobile app
 */
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { Appearance, ColorSchemeName } from 'react-native';
import { storageService } from '../shared/services/storage.service';

// Define theme types
export type ThemeType = 'light' | 'dark' | 'system';
export type ColorMode = 'light' | 'dark';
export type ThemePreference = {
  themeType: ThemeType;
  primaryColor: string;
};

// Default theme colors
export const lightColors = {
  primary: '#3B82F6', // Blue
  primaryDark: '#2563EB',
  primaryLight: '#60A5FA',
  secondary: '#10B981', // Green
  background: '#FFFFFF',
  surface: '#F9FAFB',
  error: '#EF4444',
  text: '#1F2937',
  textSecondary: '#6B7280',
  border: '#E5E7EB',
  divider: '#F3F4F6',
};

export const darkColors = {
  primary: '#60A5FA', // Lighter Blue for dark mode
  primaryDark: '#3B82F6',
  primaryLight: '#93C5FD',
  secondary: '#34D399', // Lighter Green for dark mode
  background: '#111827',
  surface: '#1F2937',
  error: '#F87171',
  text: '#F9FAFB',
  textSecondary: '#E5E7EB',
  border: '#374151',
  divider: '#374151',
};

// Theme context
type ThemeContextType = {
  theme: ThemePreference;
  colorMode: ColorMode;
  colors: typeof lightColors;
  setTheme: (theme: ThemePreference) => void;
};

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

// Theme provider props
interface ThemeProviderProps {
  children: ReactNode;
}

// Theme provider component
export const ThemeProvider: React.FC<ThemeProviderProps> = ({ children }) => {
  // Default theme
  const [theme, setThemeState] = useState<ThemePreference>({
    themeType: 'system',
    primaryColor: '#3B82F6', // Default blue
  });

  // Current color mode (light/dark)
  const [colorMode, setColorMode] = useState<ColorMode>(
    Appearance.getColorScheme() === 'dark' ? 'dark' : 'light'
  );

  // Load theme from storage on mount
  useEffect(() => {
    const loadTheme = async () => {
      try {
        const savedTheme = await storageService.getObject<ThemePreference>('theme_preference');
        if (savedTheme) {
          setThemeState(savedTheme);
        }
      } catch (error) {
        console.error('Error loading theme:', error);
      }
    };

    loadTheme();

    // Listen for system theme changes
    const subscription = Appearance.addChangeListener(({ colorScheme }) => {
      if (theme.themeType === 'system') {
        setColorMode(colorScheme === 'dark' ? 'dark' : 'light');
      }
    });

    return () => {
      subscription.remove();
    };
  }, []);

  // Update color mode when theme changes
  useEffect(() => {
    if (theme.themeType === 'system') {
      const systemColorScheme = Appearance.getColorScheme();
      setColorMode(systemColorScheme === 'dark' ? 'dark' : 'light');
    } else {
      setColorMode(theme.themeType as ColorMode);
    }
  }, [theme.themeType]);

  // Save theme to storage when it changes
  const setTheme = async (newTheme: ThemePreference) => {
    setThemeState(newTheme);
    try {
      await storageService.setObject('theme_preference', newTheme);
    } catch (error) {
      console.error('Error saving theme:', error);
    }
  };

  // Get current colors based on color mode
  const colors = colorMode === 'dark' ? darkColors : lightColors;

  // Provide theme context
  return (
    <ThemeContext.Provider value={{ theme, colorMode, colors, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

// Custom hook to use theme
export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within a ThemeProvider');
  }
  return context;
};